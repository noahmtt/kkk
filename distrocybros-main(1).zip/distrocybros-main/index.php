<?php
require_once __DIR__ . '/includes/header.php';

$stmt = $pdo->query("SELECT d.*, c.nom AS categorie FROM distributions d LEFT JOIN categories c ON d.id_cat = c.id_cat ORDER BY d.id_distro DESC LIMIT 4");
$distros = $stmt->fetchAll();
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');
?>

<div class="container">
    <!-- Fil d'Ariane -->
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / NexusDistro
    </div>

    <!-- Section Hero (Présentation + Terminal) -->
    <section class="hero">
        <div class="hero-content">
            <h1>Bienvenue sur NexusDistro</h1>
            <h2>Découvrez, comparez, téléchargez et évaluez les meilleures distributions GNU/Linux du moment.</h2>
            <p>Explorez notre sélection des dernières distributions ajoutées sur NexusDistro :</p>
            <ul>
                <?php foreach ($distros as $d): ?>
                    <li>
                        <strong><?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?></strong> (<?= htmlspecialchars($d['version'], ENT_QUOTES, 'UTF-8') ?>) — <?= htmlspecialchars($d['categorie'] ?? 'Non classé', ENT_QUOTES, 'UTF-8') ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-search --latest --limit 4</p>
                <br>
                <?php foreach ($distros as $d): ?>
                    <p>
                        [+] <strong><?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?> <?= htmlspecialchars($d['version'], ENT_QUOTES, 'UTF-8') ?></strong> 
                        [<?= htmlspecialchars($d['categorie'] ?? 'Non classé', ENT_QUOTES, 'UTF-8') ?>]
                        — <a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="cyan-link">Voir la fiche</a>
                    </p>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Section des dernières distributions ajoutées -->
    <section class="options-section">
        <h2 class="section-title">Dernières distributions ajoutées</h2>

        <!-- Grille de vignettes -->
        <div class="neofetch-grid" style="text-align: left;">
            <?php foreach ($distros as $d): 
                $hostname = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $d['nom']));
            ?>
                <article class="neofetch-card">
                    <!-- Colonne Gauche : Uniquement le gros logo -->
                    <div class="neofetch-left">
                        <div class="neofetch-logo-box">
                            <?php if (!empty($d['image_logo'])): ?>
                                <img src="<?= $safe_base_url ?>/Ressources/images/<?= htmlspecialchars(basename($d['image_logo']), ENT_QUOTES, 'UTF-8') ?>" alt="Logo <?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Colonne Droite : Toutes les colonnes de la table distributions -->
                    <div class="neofetch-right">
                        <div class="neofetch-user-host">
                            user<span>@</span><?= htmlspecialchars($hostname, ENT_QUOTES, 'UTF-8') ?>
                        </div>
                        <div class="neofetch-separator">-------------------</div>

                        <ul class="neofetch-specs">
                            <li><span class="neofetch-label">Nom:</span> <?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($d['version'], ENT_QUOTES, 'UTF-8') ?>)</li>
                            <li><span class="neofetch-label">Catégorie:</span> <?= htmlspecialchars($d['categorie'] ?? 'Non classé', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Type de l'OS:</span> <?= htmlspecialchars($d['os_type'] ?? 'Linux', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Pays:</span> <?= htmlspecialchars($d['pays_origine'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Basé sur:</span> <?= htmlspecialchars($d['base_sur'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Environnement bureau:</span> <?= htmlspecialchars($d['environnement_bureau'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Architecture:</span> <?= htmlspecialchars($d['architecture'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Format paquet:</span> <?= htmlspecialchars($d['format_paquet'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Modèle publication:</span> <?= htmlspecialchars($d['modele_publication'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Taille ISO:</span> <?= htmlspecialchars($d['taille_iso'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Mode d'installation:</span> <?= htmlspecialchars($d['methode_installation'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Support multilingue:</span> <?= htmlspecialchars($d['support_multilingue'] ?? 'Oui', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Init software:</span> <?= htmlspecialchars($d['init_software'] ?? 'systemd', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Statut:</span> <?= htmlspecialchars($d['statut'] ?? 'Actif', ENT_QUOTES, 'UTF-8') ?></li>
                        </ul>

                        <!-- Palette de couleurs + Actions -->
                        <div class="neofetch-Footer">
                            <div class="neofetch-palette">
                                <span class="pal-1"></span>
                                <span class="pal-2"></span>
                                <span class="pal-3"></span>
                                <span class="pal-4"></span>
                                <span class="pal-5"></span>
                                <span class="pal-6"></span>
                                <span class="pal-7"></span>
                                <span class="pal-8"></span>
                            </div>

                            <div class="neofetch-actions">
                                <a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="neofetch-btn">Voir la fiche →</a>
                                <?php if (!empty($d['lien_telechargement']) && preg_match('/^https?:\/\//i', $d['lien_telechargement'])): ?>
                                    <a href="<?= htmlspecialchars($d['lien_telechargement'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer" class="neofetch-btn">[ ISO ↗ ]</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>