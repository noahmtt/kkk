<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

$result = "";

if (isset($_POST['submit'])) {
    $target = $_POST['target'];

    $substitutions = array(
        '||' => '',
        '&'  => '',
        ';'  => '',
        '| ' => '',
        '-'  => '',
        '$'  => '',
        '('  => '',
        ')'  => '',
        '`'  => '',
    );

    $target = str_replace(array_keys($substitutions), $substitutions, $target);

    $cmd = "echo \"Exécution de l'action de groupe pour :\" " . $target . " 2>&1";
    $result = shell_exec($cmd);
}

if (isset($_GET['delete'])) {
    $id_del = (int)$_GET['delete'];
    if ($id_del !== (int)$_SESSION['user']['id_user']) {
        $del = $pdo->prepare("DELETE FROM utilisateurs WHERE id_user = ?");
        $del->execute([$id_del]);
    }
    header("Location: {$base_url}/pages/gestion_user.php");
    exit;
}

$users = $pdo->query("SELECT * FROM utilisateurs ORDER BY id_user ASC")->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/dashboard_admin.php">Admin</a> / Gestion des utilisateurs
    </div>

    <section class="options-section" style="margin-bottom: 30px; border-bottom: 1px solid #222; padding-bottom: 25px;">
        <h3 class="white-text" style="margin-bottom: 10px;">Console de gestion groupée NexusDistro</h3>
        <p class="comment" style="margin-bottom: 15px;"># Interface de commande pour la gestion simultanée des privilèges et des comptes.</p>
        
        <form method="POST" action="">
            <div style="display: flex; gap: 15px;">
                <input type="text" id="target" name="target" placeholder="ex: user1 user2 --role=admin" required 
                       style="background: #111; border: 1.5px solid var(--accent-cyan); color: #fff; padding: 10px; flex-grow: 1; font-family: monospace; border-radius: 4px;">
                <button type="submit" name="submit" class="cyan-link" style="background: none; border: 1.5px solid var(--accent-cyan); padding: 10px 25px; cursor: pointer; font-weight: bold;">
                    Exécuter
                </button>
            </div>
        </form>

        <?php if (!empty($result)): ?>
            <div style="margin-top: 20px;">
                <p class="comment" style="margin-bottom: 5px;"># Retour du terminal système :</p>
                <pre style="background: #000; color: #00bae4; padding: 15px; border-left: 3px solid var(--accent-cyan); font-family: monospace; white-space: pre-wrap; font-size: 0.9rem; border-radius: 0 4px 4px 0;"><?= htmlspecialchars($result) ?></pre>
            </div>
        <?php endif; ?>
    </section>

    <section class="options-section" style="border-top: none; padding-top: 0;">
        <h2 class="section-title">Comptes utilisateurs NexusDistro (<?= count($users) ?>)</h2>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; align-items: stretch;">
            <?php foreach ($users as $u): ?>
                <div class="terminal-mockup" style="display: flex; align-items: center; gap: 24px; text-align: left; height: 100%; min-height: 170px;">
                    
                    <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($u['avatar'] ?: 'default.png') ?>" 
                         alt="Avatar de <?= htmlspecialchars($u['username']) ?>" 
                         style="width: 110px; height: 110px; min-width: 110px; max-width: 110px; object-fit: cover; border-radius: 8px; border: 1.5px solid var(--accent-cyan); flex-shrink: 0;">

                    <div style="display: flex; flex-direction: column; justify-content: center; flex-grow: 1; min-width: 0;">
                        <h3 class="white-text" style="margin-bottom: 4px;">@<?= htmlspecialchars($u['username']) ?> <small>[<?= htmlspecialchars($u['role']) ?>]</small></h3>
                        <p class="comment" style="margin-bottom: 10px;"># ID : <?= (int)$u['id_user'] ?> | Email : <?= htmlspecialchars($u['email']) ?></p>
                        <p style="margin-bottom: 12px;"><?= htmlspecialchars($u['biographie'] ?: 'Aucune biographie.') ?></p>
                        <div>
                            <a href="<?= $base_url ?>/pages/promouvoir.php?id=<?= (int)$u['id_user'] ?>" class="cyan-link">
                                <?= $u['role'] === 'admin' ? 'Rétrograder en User' : 'Promouvoir en Admin' ?>
                            </a>
                            <?php if ((int)$u['id_user'] !== (int)$_SESSION['user']['id_user']): ?>
                                | <a href="<?= $base_url ?>/pages/gestion_user.php?delete=<?= (int)$u['id_user'] ?>" class="cyan-link">Supprimer</a>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
