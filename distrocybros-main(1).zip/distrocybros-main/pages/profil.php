<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

// [VULNÉRABILITÉ IDOR DANS LE CORPS DE LA REQUÊTE - Membre 2 - CWE-639]
// Si id_user est passé en POST (dans le corps de la requête, pas dans l'URL), on l'utilise sans vérifier qu'il correspond à $_SESSION['user']['id_user']
$id_user = isset($_POST['id_user']) ? (int)$_POST['id_user'] : (int)$_SESSION['user']['id_user'];

$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id_user = ?");
$stmt->execute([$id_user]);
$profil = $stmt->fetch();

if (!$profil) {
    $id_user = (int)$_SESSION['user']['id_user'];
    $stmt->execute([$id_user]);
    $profil = $stmt->fetch();
}

$nbFav = $pdo->prepare("SELECT COUNT(*) FROM favoris WHERE id_user = ?");
$nbFav->execute([$id_user]);

$nbEval = $pdo->prepare("SELECT COUNT(*) FROM evaluations WHERE id_user = ?");
$nbEval->execute([$id_user]);

$nbComm = $pdo->prepare("SELECT COUNT(*) FROM commentaires WHERE id_user = ?");
$nbComm->execute([$id_user]);
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / Mon Profil
    </div>

    <section class="hero">
        <div class="hero-content" style="display: flex; gap: 30px; align-items: flex-start;">
            
            <img src="<?= $safe_base_url ?>/Ressources/images/<?= htmlspecialchars(basename($profil['avatar'] ?: 'default.png'), ENT_QUOTES, 'UTF-8') ?>" 
                 alt="Avatar de <?= htmlspecialchars($profil['username'], ENT_QUOTES, 'UTF-8') ?>" 
                 style="width: 160px; height: 160px; object-fit: cover; border-radius: 8px; border: 1px solid var(--accent-cyan); flex-shrink: 0;">

            <div>
                <h1>Profil de <?= htmlspecialchars($profil['username'], ENT_QUOTES, 'UTF-8') ?></h1>
                <h2>Rôle : <?= htmlspecialchars(strtoupper($profil['role']), ENT_QUOTES, 'UTF-8') ?></h2>
                <p><?= nl2br(htmlspecialchars($profil['biographie'] ?: 'Aucune biographie renseignée.', ENT_QUOTES, 'UTF-8')) ?></p>
                <ul>
                    <li>Email : <?= htmlspecialchars($profil['email'], ENT_QUOTES, 'UTF-8') ?></li>
                    <li>Distributions favorites : <?= (int)$nbFav->fetchColumn() ?></li>
                    <li>Notes attribuées : <?= (int)$nbEval->fetchColumn() ?></li>
                    <li>Commentaires postés : <?= (int)$nbComm->fetchColumn() ?></li>
                </ul>
                <br>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <a href="<?= $safe_base_url ?>/pages/modifier_profil.php" class="tab-btn active" style="display: inline-block; text-decoration: none;">Modifier mon profil</a>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="id_user" value="<?= (int)$profil['id_user'] ?>">
                        <button type="submit" class="tab-btn">Actualiser la fiche</button>
                    </form>
                </div>
            </div>

        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link"><?= htmlspecialchars($profil['username'], ENT_QUOTES, 'UTF-8') ?>@nexusdistro</span>:~$ whoami --verbose</p>
                <br>
                <p class="white-text">UID        : <?= (int)$profil['id_user'] ?></p>
                <p class="white-text">Username   : <?= htmlspecialchars($profil['username'], ENT_QUOTES, 'UTF-8') ?></p>
                <p class="white-text">Groupe     : <?= htmlspecialchars($profil['role'], ENT_QUOTES, 'UTF-8') ?></p>
                <p class="white-text">Avatar     : <?= htmlspecialchars($profil['avatar'], ENT_QUOTES, 'UTF-8') ?></p>
                <p class="comment"># Bio : <?= htmlspecialchars($profil['biographie'] ?? '', ENT_QUOTES, 'UTF-8') ?></p>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>