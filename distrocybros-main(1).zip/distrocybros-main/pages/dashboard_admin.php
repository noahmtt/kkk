<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Suppression sécurisée en POST avec jeton CSRF (évite les CSRF parasites par GET)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    if (isset($_POST['del_distro'])) {
        $del = $pdo->prepare("DELETE FROM distributions WHERE id_distro = ?");
        $del->execute([(int)$_POST['del_distro']]);
        header("Location: {$base_url}/pages/dashboard_admin.php");
        exit;
    }
    if (isset($_POST['del_msg'])) {
        $del = $pdo->prepare("DELETE FROM messages_admin WHERE id_msg = ?");
        $del->execute([(int)$_POST['del_msg']]);
        header("Location: {$base_url}/pages/dashboard_admin.php");
        exit;
    }
}

$nbUsers = $pdo->query("SELECT COUNT(*) FROM utilisateurs")->fetchColumn();
$nbDistros = $pdo->query("SELECT COUNT(*) FROM distributions")->fetchColumn();
$nbMsgs = $pdo->query("SELECT COUNT(*) FROM messages_admin")->fetchColumn();

$messages = $pdo->query("
    SELECT m.*, u.username, u.email 
    FROM messages_admin m 
    JOIN utilisateurs u ON m.id_user = u.id_user 
    ORDER BY m.date_envoi DESC
")->fetchAll();

$distros = $pdo->query("SELECT d.*, c.nom AS categorie FROM distributions d LEFT JOIN categories c ON d.id_cat = c.id_cat ORDER BY d.id_distro DESC")->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / Administration NexusDistro
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Dashboard Administrateur</h1>
            <h2>Supervision de la plateforme NexusDistro et de la base <code>nexus.db</code>.</h2>
            <ul>
                <li>Utilisateurs inscrits : <strong><?= (int)$nbUsers ?></strong></li>
                <li>Distributions référencées : <strong><?= (int)$nbDistros ?></strong></li>
                <li>Messages reçus : <strong><?= (int)$nbMsgs ?></strong></li>
            </ul>
            <br>
            <div class="tabs-container" style="justify-content: flex-start;">
                <a href="<?= $safe_base_url ?>/pages/ajouter_distro.php" class="tab-btn active">+ Ajouter une distribution</a>
                <a href="<?= $safe_base_url ?>/pages/gestion_user.php" class="tab-btn">Gérer les utilisateurs</a>
                <a href="<?= $safe_base_url ?>/pages/admin_backup.php" class="tab-btn">Backup SQL</a>
            </div>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">root@nexusdistro</span>:~# systemctl status nexusdistro</p>
                <br>
                <p class="white-text">● nexusdistro.service - NexusDistro Core</p>
                <p class="white-text">   Active: active (running)</p>
                <p class="white-text">   Database: nexus.db (Connected)</p>
                <p class="comment"># Utilisez les outils ci-dessous pour gérer le contenu.</p>
            </div>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Messages des utilisateurs (<?= count($messages) ?>)</h2>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; align-items: stretch;">
            <?php foreach ($messages as $m): ?>
                <div class="terminal-mockup" style="display: flex; flex-direction: column; justify-content: space-between; text-align: left; height: 100%; min-height: 150px;">
                    <div>
                        <h3 class="white-text"><?= htmlspecialchars($m['sujet'], ENT_QUOTES, 'UTF-8') ?></h3>
                        <p class="comment"># De : <?= htmlspecialchars($m['username'], ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($m['email'], ENT_QUOTES, 'UTF-8') ?>) — <?= htmlspecialchars($m['date_envoi'], ENT_QUOTES, 'UTF-8') ?></p>
                        <br>
                        <p><?= nl2br(htmlspecialchars($m['message'], ENT_QUOTES, 'UTF-8')) ?></p>
                    </div>
                    <div style="margin-top: 15px;">
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="del_msg" value="<?= (int)$m['id_msg'] ?>">
                            <button type="submit" class="cyan-link" style="background: none; border: none; padding: 0; cursor: pointer; font: inherit;">Supprimer ce message</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Gestion des distributions (<?= count($distros) ?>)</h2>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; align-items: stretch;">
            <?php foreach ($distros as $d): ?>
                <div class="terminal-mockup" style="display: flex; align-items: center; gap: 22px; text-align: left; height: 100%; min-height: 135px;">
                    
                    <img src="<?= $safe_base_url ?>/Ressources/images/<?= htmlspecialchars(basename($d['image_logo'] ?: 'linux.png'), ENT_QUOTES, 'UTF-8') ?>" 
                         alt="Logo <?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?>" 
                         style="width: 75px; height: 75px; min-width: 75px; max-width: 75px; object-fit: contain; flex-shrink: 0;">

                    <div style="display: flex; flex-direction: column; justify-content: center; flex-grow: 1; min-width: 0;">
                        <h3 class="white-text" style="margin-bottom: 4px;"><?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?> <small>(<?= htmlspecialchars($d['version'], ENT_QUOTES, 'UTF-8') ?>)</small></h3>
                        <p class="comment" style="margin-bottom: 12px;"># Catégorie : <?= htmlspecialchars($d['categorie'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></p>
                        <div>
                            <a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="cyan-link">Voir</a> | 
                            <form method="POST" action="" style="display: inline;">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="del_distro" value="<?= (int)$d['id_distro'] ?>">
                                <button type="submit" class="cyan-link" style="background: none; border: none; padding: 0; cursor: pointer; font: inherit;">Supprimer</button>
                            </form>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>