<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$id_distro = (int)($_GET['id'] ?? $_POST['id_distro'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM distributions WHERE id_distro = ?");
$stmt->execute([$id_distro]);
$distro = $stmt->fetch();

if (!$distro) {
    header("Location: {$base_url}/pages/recherche.php");
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note'])) {
    if (isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $note = (int)$_POST['note'];
        if ($note >= 1 && $note <= 5) {
            $eval = $pdo->prepare("
                INSERT INTO evaluations (id_distro, id_user, note) 
                VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE note = VALUES(note)
            ");
            $eval->execute([$id_distro, (int)$_SESSION['user']['id_user'], $note]);
            $message = "Votre note ({$note}/5) a bien été enregistrée !";
        }
    }
}

// Récupérer la note actuelle de l'utilisateur
$cur = $pdo->prepare("SELECT note FROM evaluations WHERE id_distro = ? AND id_user = ?");
$cur->execute([$id_distro, (int)$_SESSION['user']['id_user']]);
$note_actuelle = $cur->fetchColumn();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / <a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= $id_distro ?>"><?= htmlspecialchars($distro['nom'], ENT_QUOTES, 'UTF-8') ?></a> / Évaluer
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Évaluer <?= htmlspecialchars($distro['nom'], ENT_QUOTES, 'UTF-8') ?></h1>
            <h2>Attribuez une note de 1 à 5 à la version <?= htmlspecialchars($distro['version'], ENT_QUOTES, 'UTF-8') ?>.</h2>
            <?php if ($note_actuelle): ?>
                <p>Votre note actuelle : <strong><?= (int)$note_actuelle ?> / 5</strong></p>
            <?php endif; ?>
            <p><a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= $id_distro ?>" class="cyan-link">← Retourner sur la fiche de la distribution</a></p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-rate --distro <?= $id_distro ?></p>
                <br>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>

                <?php
                // [VULNÉRABILITÉ XSS RÉFLÉCHIE - Membre 1 (Noah) - CWE-79]
                // Si Noah utilise un paramètre GET (ex: ?id=1&avis=...) renvoyé sans htmlspecialchars() :
                if (isset($_GET['avis'])): ?>
                    <p class="white-text">[+] Aperçu de votre avis : <?= $_GET['avis'] ?></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="id_distro" value="<?= $id_distro ?>">
                    <div class="tabs-container">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <button type="submit" name="note" value="<?= $i ?>" class="tab-btn <?= (int)$note_actuelle === $i ? 'active' : '' ?>">
                                <?= $i ?> ★
                            </button>
                        <?php endfor; ?>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>