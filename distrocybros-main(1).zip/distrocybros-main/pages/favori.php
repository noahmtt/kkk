<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

$id_user = (int)$_SESSION['user']['id_user'];

// Action d'ajout / suppression rapide
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'toggle') {
    $id_distro = (int)$_GET['id'];

    // Vérifier que la distribution existe réellement avant d'agir
    $distroExists = $pdo->prepare("SELECT id_distro FROM distributions WHERE id_distro = ?");
    $distroExists->execute([$id_distro]);

    if ($distroExists->fetch()) {
        $check = $pdo->prepare("SELECT id_favori FROM favoris WHERE id_user = ? AND id_distro = ?");
        $check->execute([$id_user, $id_distro]);

        if ($check->fetch()) {
            $del = $pdo->prepare("DELETE FROM favoris WHERE id_user = ? AND id_distro = ?");
            $del->execute([$id_user, $id_distro]);
        } else {
            $ins = $pdo->prepare("INSERT INTO favoris (id_user, id_distro) VALUES (?, ?)");
            $ins->execute([$id_user, $id_distro]);
        }
    }
    header("Location: {$base_url}/pages/favori.php");
    exit;
}

$stmt = $pdo->prepare("
    SELECT d.*, c.nom AS categorie 
    FROM favoris f
    JOIN distributions d ON f.id_distro = d.id_distro
    LEFT JOIN categories c ON d.id_cat = c.id_cat
    WHERE f.id_user = ?
    ORDER BY f.id_favori DESC
");
$stmt->execute([$id_user]);
$favoris = $stmt->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / Mes Favoris
    </div>

    <section class="options-section" style="border-top: none; padding-top: 0;">
        <h2 class="section-title">Mes distributions favorites (<?= count($favoris) ?>)</h2>

        <?php if (empty($favoris)): ?>
            <div class="code-block">
                <p class="comment"># Aucune distribution dans vos favoris pour le moment.</p>
                <p><a href="<?= $safe_base_url ?>/pages/recherche.php" class="cyan-link">Parcourir NexusDistro →</a></p>
            </div>
        <?php else: ?>
            <div class="hero">
                <?php foreach ($favoris as $d): ?>
                    <div class="terminal-mockup">
                        <h3 class="white-text"><?= htmlspecialchars($d['nom'], ENT_QUOTES, 'UTF-8') ?> <small>(<?= htmlspecialchars($d['version'], ENT_QUOTES, 'UTF-8') ?>)</small></h3>
                        <p class="comment"># Catégorie : <?= htmlspecialchars($d['categorie'] ?? 'Non classé', ENT_QUOTES, 'UTF-8') ?></p>
                        <br>
                        <p><?= htmlspecialchars($d['description'], ENT_QUOTES, 'UTF-8') ?></p>
                        <br>
                        <a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="cyan-link">Voir la fiche</a> | 
                        <a href="<?= $safe_base_url ?>/pages/favori.php?action=toggle&id=<?= (int)$d['id_distro'] ?>" class="cyan-link">Retirer des favoris</a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>