<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

// Vérification obligatoire du Token CSRF (exigé pour le challenge XSS réfléchie -> récupération du token CSRF -> CSRF du Membre 1)
$token = $_REQUEST['csrf_token'] ?? '';
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    http_response_code(403);
    die("Erreur CSRF : Jeton de sécurité manquant ou invalide.");
}

$id_user = (int)($_REQUEST['id'] ?? 0);

// On empêche l'administrateur de se rétrograder lui-même accidentellement
if ($id_user > 0 && $id_user !== (int)$_SESSION['user']['id_user']) {
    $stmt = $pdo->prepare("SELECT id_user, username, role FROM utilisateurs WHERE id_user = ?");
    $stmt->execute([$id_user]);
    $u = $stmt->fetch();

    if ($u) {
        $nouveau_role = ($u['role'] === 'admin') ? 'user' : 'admin';
        $upd = $pdo->prepare("UPDATE utilisateurs SET role = ? WHERE id_user = ?");
        $upd->execute([$nouveau_role, $id_user]);
    }
}

header("Location: {$base_url}/pages/gestion_user.php");
exit;