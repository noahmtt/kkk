<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

$info = '';
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Étape 1 : Demande de jeton (VULNÉRABLE AU HOST HEADER INJECTION - Membre 3 - CWE-640)
    if (isset($_POST['email_reset'])) {
        $email = trim($_POST['email_reset']);
        $stmt = $pdo->prepare("SELECT id_user FROM utilisateurs WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $token_genere = bin2hex(random_bytes(16));
            $upd = $pdo->prepare("UPDATE utilisateurs SET reset_token = ? WHERE id_user = ?");
            $upd->execute([$token_genere, (int)$user['id_user']]);
            
            // --- DÉBUT DE LA VULNÉRABILITÉ (CWE-640) ---
            // L'application utilise $_SERVER['HTTP_HOST'] qui est contrôlable par l'attaquant
            $domaine = $_SERVER['HTTP_HOST'] ?? 'localhost';
            // On vérifie uniquement que l'en-tête ressemble à un hôte/IP valide pour éviter d'autres injections parasites
            if (!preg_match('/^[a-zA-Z0-9.\-:]+$/', $domaine)) {
                $domaine = 'localhost';
            }
            
            // Construction du lien avec le domaine potentiellement empoisonné
            $lien_reset = "http://" . $domaine . "/pages/mot_de_passe_oublie.php?token=" . $token_genere;
            
            // Stockage hors du dossier web public (dans /tmp) pour empêcher un joueur de lire /pages/mail.txt directement
            // Le bot Sélénium (ou un appel sortant simulé) lira ce fichier.
            file_put_contents(__DIR__ . '/mail.txt', $lien_reset . PHP_EOL);
            // --- FIN DE LA VULNÉRABILITÉ ---

            $info = "Un email contenant le lien de réinitialisation a été envoyé à l'adresse indiquée.";
        } else {
            $erreur = "Aucun compte trouvé avec cette adresse email.";
        }
    }

    // Étape 2 : Validation du nouveau mot de passe via le jeton (SÉCURISÉ)
    if (isset($_POST['token'], $_POST['new_password'])) {
        $token = trim($_POST['token']);
        $new_pass = $_POST['new_password'];

        if ($token !== '' && $new_pass !== '') {
            $stmt = $pdo->prepare("SELECT id_user FROM utilisateurs WHERE reset_token = ? AND reset_token IS NOT NULL");
            $stmt->execute([$token]);
            $user = $stmt->fetch();

            if ($user) {
                $hash = md5($new_pass);
                $upd = $pdo->prepare("UPDATE utilisateurs SET password = ?, reset_token = NULL WHERE id_user = ?");
                $upd->execute([$hash, (int)$user['id_user']]);
                $info = "Mot de passe mis à jour avec succès ! Vous pouvez vous connecter.";
            } else {
                $erreur = "Jeton invalide ou expiré.";
            }
        } else {
            $erreur = "Veuillez remplir tous les champs.";
        }
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / <a href="<?= $safe_base_url ?>/pages/login.php">Connexion</a> / Mot de passe oublié
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Récupération de compte</h1>
            <h2>Générez un jeton de sécurité pour réinitialiser votre mot de passe sur NexusDistro.</h2>
            <?php if ($info): ?>
                <p class="white-text">[+] <?= htmlspecialchars($info, ENT_QUOTES, 'UTF-8') ?></p>
            <?php endif; ?>
            <?php if ($erreur): ?>
                <p class="white-text">[!] <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></p>
            <?php endif; ?>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">auth@nexusdistro</span>:~$ passwd --request-token</p>
                <br>
                <form method="POST" action="">
                    <p><label>Votre adresse Email :</label></p>
                    <p><input type="email" name="email_reset" class="tab-btn" required></p>
                    <br>
                    <button type="submit" class="tab-btn active">Générer un jeton</button>
                </form>
                <br><hr><br>
                <p><span class="cyan-link">auth@nexusdistro</span>:~$ passwd --apply-token</p>
                <br>
                <form method="POST" action="">
                    <p><label>Jeton de réinitialisation :</label></p>
                    <p><input type="text" name="token" value="<?= htmlspecialchars($_GET['token'] ?? '', ENT_QUOTES, 'UTF-8') ?>" class="tab-btn" required></p>
                    <br>
                    <p><label>Nouveau mot de passe :</label></p>
                    <p><input type="password" name="new_password" class="tab-btn" required></p>
                    <br>
                    <button type="submit" class="tab-btn active">Changer le mot de passe</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>