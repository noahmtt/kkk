<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

// [VULNÉRABILITÉ IDOR DANS LE CORPS DE LA REQUÊTE - Membre 2 - CWE-639]
// Pas de vérification entre l'ID de session ($_SESSION['user']['id_user']) et l'ID envoyé dans le corps POST ($_POST['id_user'])
$id_user = isset($_POST['id_user']) ? (int)$_POST['id_user'] : (int)$_SESSION['user']['id_user'];

$message = '';
$erreur = '';
$cmd_output = '';

// On récupère les infos de l'utilisateur ciblé
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id_user = ?");
$stmt->execute([$id_user]);
$profil = $stmt->fetch();

if (!$profil) {
    header("Location: {$base_url}/pages/profil.php");
    exit;
}

// Chemin vers le dossier de destination des images
$upload_dir = __DIR__ . '/../Ressources/images/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $biographie = trim($_POST['biographie'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    
    $avatar = $profil['avatar'] ?: 'default.png';

    // [VULNÉRABILITÉ FILE UPLOAD PAR LISTE NOIRE - Membre 4 - CWE-434]
    // Filtrage par liste noire contournable via .htaccess + extension alternative (.pht, .phar, etc.)
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['avatar']['tmp_name'];
            $original_name = basename($_FILES['avatar']['name']);
            $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

            // MODIFICATION UNIQUEMENT ICI : 'php' a été retiré de la liste noire pour vos tests
            $blacklist = ['php3', 'php4', 'php5', 'phtml', 'exe', 'sh'];

            if (in_array($ext, $blacklist, true)) {
                $erreur = "Sécurité : Les fichiers exécutables (.$ext) ne sont pas autorisés.";
            } else {
                $target_path = $upload_dir . $original_name;

                if (move_uploaded_file($tmp_name, $target_path)) {
                    $avatar = $original_name;

                    // [VULNÉRABILITÉ INJECTION DE COMMANDE - Membre 4 - CWE-78]
                    // Aucun contrôle sur le nom du fichier passé à la commande système (comme décrit dans le document de cadrage)
                    $cmd_output = shell_exec("file " . $target_path . " 2>&1");
                } else {
                    $erreur = "Votre image n'a pas pu être enregistrée.";
                }
            }
        } else {
            $erreur = "Erreur lors de l'envoi du fichier.";
        }
    }

    if ($email !== '' && $erreur === '') {
        $upd = $pdo->prepare("UPDATE utilisateurs SET email = ?, biographie = ?, avatar = ? WHERE id_user = ?");
        $upd->execute([$email, $biographie, $avatar, $id_user]);

        // CODE DU COLLÈGUE CONSERVÉ À 100 % (IDOR SUR LE MOT DE PASSE SANS VÉRIF)
        if ($new_password !== '') {
            $hash = md5($new_password);
            $updPass = $pdo->prepare("UPDATE utilisateurs SET password = ? WHERE id_user = ?");
            $updPass->execute([$hash, $id_user]);
        }

        if ($id_user === (int)$_SESSION['user']['id_user']) {
            $_SESSION['user']['email'] = $email;
            $_SESSION['user']['avatar'] = $avatar;
        }
        $message = "Le profil (UID: {$id_user}) a été mis à jour avec succès.";

        // On rafraîchit les données affichées sur la page
        $stmt->execute([$id_user]);
        $profil = $stmt->fetch();
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / <a href="<?= $safe_base_url ?>/pages/profil.php">Profil</a> / Modifier mon profil
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Modifier mon profil</h1>
            <h2>Mettez à jour vos informations personnelles sur NexusDistro.</h2>
            <p><a href="<?= $safe_base_url ?>/pages/profil.php" class="cyan-link">← Retour au profil</a></p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link"><?= htmlspecialchars($profil['username'], ENT_QUOTES, 'UTF-8') ?>@nexusdistro</span>:~$ usermod --edit --uid <?= (int)$profil['id_user'] ?></p>
                <br>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>
                <?php if ($cmd_output): ?>
                    <p class="comment"># Vérification MIME : <?= htmlspecialchars($cmd_output, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>
                <?php if ($erreur): ?>
                    <p class="white-text" style="color: #ff5555;">[!] <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>

                <form method="POST" action="" enctype="multipart/form-data">
                    <!-- Champ ID utilisateur dans le corps de la requête pour l'IDOR du Membre 2 -->
                    <input type="hidden" name="id_user" value="<?= (int)$profil['id_user'] ?>">

                    <p><label>Email :</label></p>
                    <p><input type="email" name="email" value="<?= htmlspecialchars($profil['email'], ENT_QUOTES, 'UTF-8') ?>" class="tab-btn" required></p>
                    <br>
                    <p><label>Importer un nouvel Avatar (actuel : <?= htmlspecialchars($profil['avatar'], ENT_QUOTES, 'UTF-8') ?>) :</label></p>
                    <p><input type="file" name="avatar" class="tab-btn"></p>
                    <br>
                    <p><label>Biographie :</label></p>
                    <p><textarea name="biographie" rows="4" class="tab-btn"><?= htmlspecialchars($profil['biographie'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea></p>
                    <br>
                    <p><label>Nouveau mot de passe (laisser vide pour conserver l'actuel) :</label></p>
                    <p><input type="password" name="new_password" class="tab-btn"></p>
                    <br>
                    <button type="submit" class="tab-btn active">Enregistrer les modifications</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
