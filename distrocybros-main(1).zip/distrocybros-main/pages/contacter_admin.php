<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

// 1. Vérification de la connexion de l'utilisateur
if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

// 2. Génération du jeton CSRF pour le formulaire s'il n'existe pas
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message_ok = '';
$erreur = '';
$bot_status = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // --- ACTION A : L'utilisateur déclenche le bot Selenium ---
    if (isset($_POST['lancer_bot'])) {
        touch('/var/www/html/run_bot.flag');
// Ta commande exacte pour lancer le bot en arrière-plan sans bloquer la page
       // $cmd = "sudo -u lamp_admin HOME=/tmp /usr/bin/python3 /var/www/html/hihi.py > /var/www/html/bot.log 2>&1 &";
        //exec($cmd);
        
        $bot_status = "Vérifiez les logs avec 'sudo tail -f /var/www/html/bot.log'.";
    } 
    
    // --- ACTION B : L'utilisateur envoie un message (ticket CTF) ---
    elseif (isset($_POST['sujet']) && isset($_POST['message'])) {
        // Vérification du jeton CSRF
        if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            $erreur = "Jeton de sécurité CSRF invalide.";
        } else {
            $sujet = trim($_POST['sujet']);
            $message = trim($_POST['message']);

            if ($sujet !== '' && $message !== '') {
                // Insertion du ticket dans la base de données
                $stmt = $pdo->prepare("INSERT INTO messages_admin (id_user, sujet, message) VALUES (?, ?, ?)");
                $stmt->execute([(int)$_SESSION['user']['id_user'], $sujet, $message]);
                $message_ok = "Votre message (et votre lien) a bien été transmis aux administrateurs de NexusDistro.";
            } else {
                $erreur = "Veuillez remplir tous les champs.";
            }
        }
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / Contacter l'administrateur
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Contacter l'équipe NexusDistro</h1>
            <h2>Suggérez l'ajout d'une nouvelle distribution GNU/Linux ou signalez un problème technique.</h2>
            <p>Votre message sera directement visible dans le tableau de bord d'administration.</p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link"><?= htmlspecialchars($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8') ?>@nexusdistro</span>:~$ mail -s "Support" admin@nexusdistro</p>
                <br>
                
                <!-- Affichage des alertes et retours d'information -->
                <?php if ($message_ok): ?>
                    <p class="white-text" style="color: #00ffcc;">[+] <?= htmlspecialchars($message_ok, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>
                
                <?php if ($erreur): ?>
                    <p class="white-text" style="color: #ff5555;">[!] <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>
                
                <?php if ($bot_status): ?>
                    <p class="white-text" style="color: #ffff00;">[⚙️] <?= htmlspecialchars($bot_status, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>

                <!-- Formulaire 1 : Envoi du message avec le lien piégé -->
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <p><label>Sujet :</label></p>
                    <p><input type="text" name="sujet" class="tab-btn" style="width: 100%; text-align: left;" required></p>
                    <br>
                    <p><label>Message (collez votre URL ici) :</label></p>
                    <p><textarea name="message" rows="5" class="tab-btn" style="width: 100%; text-align: left;" required></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">Envoyer le message</button>
                </form>

                <hr style="border: 1px dashed #333; margin: 30px 0;">

                <!-- Formulaire 2 : Déclenchement du bot administrateur -->
                <p style="color: #888; font-size: 0.9em;">(Zone de test CTF)</p>
                <form method="POST" action="">
                    <button type="submit" name="lancer_bot" class="tab-btn" style="border-color: #ffaa00; color: #ffaa00; cursor: pointer;">
                        🤖 Simuler la visite de l'administrateur
                    </button>
                </form>

            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
