<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

$q = trim($_GET['q'] ?? '');
$cat = (int)($_GET['cat'] ?? 0);

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom ASC")->fetchAll();

// [VULNÉRABILITÉ SQLi UNION - Membre 1 (Noah) - CWE-89]
// Concaténation directe de $q pour permettre une injection SQL de type UNION
$sql = "SELECT d.*, c.nom AS categorie, COALESCE(AVG(e.note), 0) AS moyenne
        FROM distributions d
        LEFT JOIN categories c ON d.id_cat = c.id_cat
        LEFT JOIN evaluations e ON d.id_distro = e.id_distro
        WHERE 1=1";

if ($q !== '') {
    $sql .= " AND (d.nom LIKE '%$q%' OR d.description LIKE '%$q%' OR d.version LIKE '%$q%')";
}
if ($cat > 0) {
    $sql .= " AND d.id_cat = " . $cat;
}

$sql .= " GROUP BY d.id_distro ORDER BY d.nom ASC";

$resultats = [];
try {
    $stmt = $pdo->query($sql);
    if ($stmt) {
        $resultats = $stmt->fetchAll();
    }
} catch (PDOException $e) {
    // Masquage des erreurs brutes pour éviter la divulgation d'informations système hors périmètre
    $resultats = [];
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / Recherche de distributions
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Explorer NexusDistro</h1>
            <h2>Recherchez une distribution par nom, mot-clé ou catégorie d'utilisation.</h2>
            <p><?= count($resultats) ?> distribution(s) trouvée(s) dans la base.</p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-search --query</p>
                <br>
                <form method="GET" action="">
                    <p><input type="text" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>" placeholder="Ex: Kali, Debian, LTS..." class="tab-btn"></p>
                    <br>
                    <p>
                        <select name="cat" class="tab-btn">
                            <option value="0">-- Toutes les catégories --</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id_cat'] ?>" <?= $cat === (int)$c['id_cat'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['nom'], ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </p>
                    <br>
                    <button type="submit" class="tab-btn active">Lancer la recherche</button>
                    <a href="<?= $safe_base_url ?>/pages/recherche.php" class="cyan-link">Réinitialiser</a>
                </form>
            </div>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Filtrer par catégorie</h2>
        <div class="tabs-container">
            <a href="<?= $safe_base_url ?>/pages/recherche.php" class="tab-btn <?= $cat === 0 ? 'active' : '' ?>">Toutes</a>
            <?php foreach ($categories as $c): ?>
                <a href="<?= $safe_base_url ?>/pages/recherche.php?cat=<?= (int)$c['id_cat'] ?>&q=<?= urlencode($q) ?>" class="tab-btn <?= $cat === (int)$c['id_cat'] ? 'active' : '' ?>">
                    <?= htmlspecialchars($c['nom'], ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- Grille de résultats en vignettes -->
        <div class="neofetch-grid" style="text-align: left;">
            <?php foreach ($resultats as $d): 
                $hostname = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $d['nom'] ?? ''));
            ?>
                <article class="neofetch-card">
                    <!-- Colonne Gauche : Uniquement le gros logo -->
                    <div class="neofetch-left">
                        <div class="neofetch-logo-box">
                            <?php if (!empty($d['image_logo'])): ?>
                                <img src="<?= $safe_base_url ?>/Ressources/images/<?= htmlspecialchars(basename($d['image_logo']), ENT_QUOTES, 'UTF-8') ?>" alt="Logo <?= htmlspecialchars($d['nom'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Colonne Droite : Toutes les colonnes de la table distributions -->
                    <div class="neofetch-right">
                        <div class="neofetch-user-host">
                            user<span>@</span><?= htmlspecialchars($hostname, ENT_QUOTES, 'UTF-8') ?>
                        </div>
                        <div class="neofetch-separator">-------------------</div>

                        <ul class="neofetch-specs">
                            <li><span class="neofetch-label">Nom:</span> <?= htmlspecialchars($d['nom'] ?? '', ENT_QUOTES, 'UTF-8') ?> (<?= htmlspecialchars($d['version'] ?? '', ENT_QUOTES, 'UTF-8') ?>)</li>
                            <li><span class="neofetch-label">Catégorie:</span> <?= htmlspecialchars($d['categorie'] ?? 'Non classé', ENT_QUOTES, 'UTF-8') ?> | <span class="neofetch-label">Note:</span> <?= number_format((float)($d['moyenne'] ?? 0), 1) ?>/5</li>
                            <li><span class="neofetch-label">Type de l'OS:</span> <?= htmlspecialchars($d['os_type'] ?? 'Linux', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Pays:</span> <?= htmlspecialchars($d['pays_origine'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Basé sur:</span> <?= htmlspecialchars($d['base_sur'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Environnement bureau:</span> <?= htmlspecialchars($d['environnement_bureau'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Architecture:</span> <?= htmlspecialchars($d['architecture'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Format paquet:</span> <?= htmlspecialchars($d['format_paquet'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Modèle publication:</span> <?= htmlspecialchars($d['modele_publication'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Taille ISO:</span> <?= htmlspecialchars($d['taille_iso'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Mode d'installation:</span> <?= htmlspecialchars($d['methode_installation'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Support multilingue:</span> <?= htmlspecialchars($d['support_multilingue'] ?? 'Oui', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Init software:</span> <?= htmlspecialchars($d['init_software'] ?? 'systemd', ENT_QUOTES, 'UTF-8') ?></li>
                            <li><span class="neofetch-label">Statut:</span> <?= htmlspecialchars($d['statut'] ?? 'Actif', ENT_QUOTES, 'UTF-8') ?></li>
                        </ul>

                        <!-- Palette de couleurs + Actions -->
                        <div class="neofetch-Footer">
                            <div class="neofetch-palette">
                                <span class="pal-1"></span>
                                <span class="pal-2"></span>
                                <span class="pal-3"></span>
                                <span class="pal-4"></span>
                                <span class="pal-5"></span>
                                <span class="pal-6"></span>
                                <span class="pal-7"></span>
                                <span class="pal-8"></span>
                            </div>

                            <div class="neofetch-actions">
                                <a href="<?= $safe_base_url ?>/pages/description_distro.php?id=<?= (int)($d['id_distro'] ?? 0) ?>" class="neofetch-btn">Voir la fiche complète →</a>
                                <?php if (!empty($d['lien_telechargement']) && preg_match('/^https?:\/\//i', $d['lien_telechargement'])): ?>
                                    <a href="<?= htmlspecialchars($d['lien_telechargement'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer" class="neofetch-btn">[ ISO ↗ ]</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>