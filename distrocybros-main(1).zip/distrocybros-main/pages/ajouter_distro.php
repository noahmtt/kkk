<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom ASC")->fetchAll();
$message = '';
$erreur = '';

$upload_dir = __DIR__ . '/../Ressources/images/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $erreur = "Jeton CSRF invalide.";
    } else {
        $nom = trim($_POST['nom'] ?? '');
        $version = trim($_POST['version'] ?? '');
        $id_cat = (int)($_POST['id_cat'] ?? 0) ?: null;
        $description = trim($_POST['description'] ?? '');
        $lien = trim($_POST['lien_telechargement'] ?? '');
        $logo = 'linux.png';

        if ($lien !== '' && (!filter_var($lien, FILTER_VALIDATE_URL) || !preg_match('/^https?:\/\//i', $lien))) {
            $erreur = "Le lien de téléchargement doit être une URL valide commençant par http:// ou https://.";
        }

        // Si un fichier logo a été sélectionné (Sécurisé contre le File Upload et XSS SVG)
        if ($erreur === '' && isset($_FILES['image_logo']) && $_FILES['image_logo']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['image_logo']['error'] === UPLOAD_ERR_OK) {
                $tmp_name = $_FILES['image_logo']['tmp_name'];
                $original_name = basename($_FILES['image_logo']['name']);
                $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
                // Retrait de 'svg' pour bloquer les XSS stockées via image SVG
                $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];
                $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];

                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $tmp_name);
                finfo_close($finfo);

                if (!in_array($ext, $allowed_exts, true) || !in_array($mime, $allowed_mimes, true)) {
                    $erreur = "Format d'image non supporté. Utilisez uniquement PNG, JPG, WEBP ou GIF.";
                } else {
                    $clean_name = preg_replace('/[^A-Za-z0-9._-]/', '_', pathinfo($original_name, PATHINFO_FILENAME)) . '.' . $ext;

                    if (move_uploaded_file($tmp_name, $upload_dir . $clean_name)) {
                        $logo = $clean_name;
                    } else {
                        $erreur = "Impossible d'enregistrer le logo sur le serveur.";
                    }
                }
            } else {
                $erreur = "Erreur lors de l'envoi du logo (fichier trop volumineux).";
            }
        }

        if ($nom !== '' && $version !== '' && $erreur === '') {
            $stmt = $pdo->prepare("
                INSERT INTO distributions (
                    nom, version, id_cat, pays_origine, base_sur, environnement_bureau,
                    architecture, format_paquet, modele_publication, taille_iso, methode_installation,
                    description, lien_telechargement, image_logo
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $nom,
                $version,
                $id_cat,
                'Global',
                'Indépendante',
                'Au choix',
                'x86_64',
                'NC',
                'Fixed',
                'NC',
                'GUI / CLI',
                $description,
                $lien,
                $logo
            ]);
            $message = "La distribution {$nom} a été ajoutée à NexusDistro avec le logo {$logo} !";
        }
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / <a href="<?= $safe_base_url ?>/pages/dashboard_admin.php">Admin</a> / Ajouter une distribution
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Ajouter une distribution</h1>
            <h2>Référencez une nouvelle distribution GNU/Linux dans la base <code>nexus.db</code>.</h2>
            <p><a href="<?= $safe_base_url ?>/pages/dashboard_admin.php" class="cyan-link">← Retour au Dashboard</a></p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">root@nexusdistro</span>:~# nexus-pkg --add-distro</p>
                <br>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>
                <?php if ($erreur): ?>
                    <p class="white-text" style="color: #ff5555;">[!] <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>

                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <p><label>Nom de la distribution * :</label></p>
                    <p><input type="text" name="nom" class="tab-btn" required></p>
                    <br>
                    <p><label>Version * :</label></p>
                    <p><input type="text" name="version" class="tab-btn" required></p>
                    <br>
                    <p><label>Catégorie :</label></p>
                    <p>
                        <select name="id_cat" class="tab-btn">
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id_cat'] ?>"><?= htmlspecialchars($c['nom'], ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </p>
                    <br>
                    <p><label>Lien de téléchargement (ISO) :</label></p>
                    <p><input type="url" name="lien_telechargement" class="tab-btn"></p>
                    <br>
                    <p><label>Importer le fichier Logo :</label></p>
                    <p><input type="file" name="image_logo" accept="image/png,image/jpeg,image/webp,image/gif" class="tab-btn"></p>
                    <br>
                    <p><label>Description :</label></p>
                    <p><textarea name="description" rows="4" class="tab-btn" required></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">Ajouter au catalogue</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>