<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $erreur = "Erreur de sécurité : Jeton CSRF invalide.";
    } else {
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $biographie = trim($_POST['biographie'] ?? '');

        if ($username !== '' && $email !== '' && $password !== '') {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $erreur = "Format d'adresse email invalide.";
            } else {
                $check = $pdo->prepare("SELECT id_user FROM utilisateurs WHERE username = ? OR email = ?");
                $check->execute([$username, $email]);
                if ($check->fetch()) {
                    $erreur = "Ce nom d'utilisateur ou cet email est déjà utilisé.";
                } else {
                    // Aligné avec login.php et mot_de_passe_oublie.php qui utilisent MD5
                    $hash = md5($password);
                    $stmt = $pdo->prepare("INSERT INTO utilisateurs (username, email, password, role, biographie) VALUES (?, ?, ?, 'user', ?)");
                    $stmt->execute([$username, $email, $hash, $biographie]);
                    $message = "Compte créé avec succès ! Vous pouvez maintenant vous connecter.";
                }
            }
        } else {
            $erreur = "Veuillez remplir tous les champs obligatoires.";
        }
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / Inscription
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Rejoindre NexusDistro</h1>
            <h2>Créez votre profil pour partager vos avis, noter vos systèmes favoris et échanger avec la communauté.</h2>
            <p>Avantages membres :</p>
            <ul>
                <li>Sauvegarde de vos distributions favorites</li>
                <li>Publication de commentaires et d'évaluations</li>
                <li>Contact direct avec l'équipe d'administration</li>
            </ul>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ useradd --create-profile</p>
                <br>
                <?php if ($erreur): ?>
                    <p class="white-text">[!] <?= htmlspecialchars($erreur, ENT_QUOTES, 'UTF-8') ?></p><br>
                <?php endif; ?>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?> <a href="<?= $safe_base_url ?>/pages/login.php" class="cyan-link">Connexion →</a></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                    <p><label>Nom d'utilisateur * :</label></p>
                    <p><input type="text" name="username" class="tab-btn" required></p>
                    <br>
                    <p><label>Email * :</label></p>
                    <p><input type="email" name="email" class="tab-btn" required></p>
                    <br>
                    <p><label>Mot de passe * :</label></p>
                    <p><input type="password" name="password" class="tab-btn" required></p>
                    <br>
                    <p><label>Biographie :</label></p>
                    <p><textarea name="biographie" rows="3" class="tab-btn"></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">S'inscrire</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>