<?php
require_once __DIR__ . '/../includes/header.php';
$safe_base_url = htmlspecialchars($base_url, ENT_QUOTES, 'UTF-8');

// [VULNÉRABILITÉ FORCED BROWSING - CWE-425]
// Oubli volontaire de la vérification du rôle admin pour l'accès à la page :
// if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
//     header("Location: {$base_url}/index.php");
//     exit;
// }

// [PROTECTION ANTI-SQLMAP] (Exigence du document de cadrage)
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (stripos($user_agent, 'sqlmap') !== false) {
    http_response_code(403);
    die("<div class='container'><div class='terminal-mockup' style='border-color: #ff4b4b; color: #ff4b4b;'>
        [!] ALERTE IDS : Outil automatisé (sqlmap) détecté.<br>
        Ce challenge doit être résolu à l'aide d'un script personnalisé (Python ou Bash).
    </div></div>");
}

// SÉCURITÉ CTF : On bloque le téléchargement complet de la base si l'utilisateur n'est pas réellement admin,
// sinon le pentester qui trouve la page par fuzzing téléchargerait toute la BDD sans faire la SQLi Blind !
$download_error = '';
if (isset($_GET['download']) && $_GET['download'] === '1') {
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
        $download_error = "Erreur : Le téléchargement complet du fichier .SQL nécessite une élévation de privilèges administrateur active.";
    } else {
        ob_clean();
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="backup_nexus_' . date('Y-m-d_H-i') . '.sql"');

        echo "-- Sauvegarde NexusDistro (Base : `nexus.db`)\n";
        echo "-- Date : " . date('Y-m-d H:i:s') . "\n\n";

        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $table) {
            $safe_table = str_replace('`', '``', $table);
            $create = $pdo->query("SHOW CREATE TABLE `{$safe_table}`")->fetch();
            echo "DROP TABLE IF EXISTS `{$safe_table}`;\n";
            echo $create['Create Table'] . ";\n\n";

            $rows = $pdo->query("SELECT * FROM `{$safe_table}`")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                $cols = array_map(fn($c) => "`" . str_replace('`', '``', $c) . "`", array_keys($row));
                $vals = array_map(fn($v) => $v === null ? "NULL" : $pdo->quote($v), array_values($row));
                echo "INSERT INTO `{$safe_table}` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");\n";
            }
            echo "\n";
        }
        exit;
    }
}

// Traitement du formulaire d'audit d'utilisateur (SQLi Boolean Blind)
$check_result = null;
if (isset($_POST['username_check']) && $_POST['username_check'] !== '') {
    $searched_user = $_POST['username_check'];

    // [VULNÉRABILITÉ SQLi BOOLEAN BLIND - CWE-89]
    // Concaténation directe de l'entrée utilisateur sans requête préparée
    $sql = "SELECT id_user FROM utilisateurs WHERE username = '$searched_user'";

    try {
        $stmt = $pdo->query($sql);
        // On ne récupère aucune donnée à afficher : on vérifie seulement si au moins 1 ligne existe
        if ($stmt && $stmt->fetch()) {
            $check_result = true;
        } else {
            $check_result = false;
        }
    } catch (PDOException $e) {
        // On masque l'erreur SQL pour empêcher les attaques Error-Based et forcer le Blind
        $check_result = false;
    }
}

$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $safe_base_url ?>/index.php">Accueil</a> / <a href="<?= $safe_base_url ?>/pages/dashboard_admin.php">Admin</a> / Sauvegarde & Audit Base de données
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Maintenance & Sauvegarde de <code>nexus.db</code></h1>
            <h2>Vérifiez l'intégrité des comptes dans la base ou exportez les tables au format SQL.</h2>
            <p>Tables détectées dans <code>nexus.db</code> :</p>
            <ul>
                <?php foreach ($tables as $t): ?>
                    <li><code><?= htmlspecialchars($t, ENT_QUOTES, 'UTF-8') ?></code></li>
                <?php endforeach; ?>
            </ul>
            <br>
            <?php if ($download_error): ?>
                <p style="color: #ff5555;">[!] <?= htmlspecialchars($download_error, ENT_QUOTES, 'UTF-8') ?></p><br>
            <?php endif; ?>
            <a href="<?= $safe_base_url ?>/pages/admin_backup.php?download=1" class="tab-btn active">Télécharger le fichier .SQL</a>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">root@nexusdistro</span>:~# nexus-db-check --verify-user</p>
                <br>
                <form method="POST" action="">
                    <p><label>Vérifier l'existence d'un utilisateur dans la sauvegarde :</label></p>
                    <p><input type="text" name="username_check" class="tab-btn" placeholder="Ex: admin" required></p>
                    <br>
                    <button type="submit" class="tab-btn active">Vérifier la présence en base</button>
                </form>
                <br>
                <?php if ($check_result === true): ?>
                    <p class="white-text" style="color: #50fa7b;">[+] L'utilisateur est déjà créé dans la base.</p>
                <?php elseif ($check_result === false): ?>
                    <p class="white-text" style="color: #ff5555;">[-] L'utilisateur n'existe pas dans la base.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>