#!/bin/bash
TRIGGER="/var/www/html/run_bot.flag"

while true; do
    if [ -f "$TRIGGER" ]; then
        rm -f "$TRIGGER"
        echo "[$(date)] Bouton activé depuis le site web !" >> /var/www/html/bot.log
        HOME=/tmp /usr/bin/python3 /var/www/html/bot_admin.py >> /var/www/html/bot.log 2>&1
    fi
    sleep 1
done
