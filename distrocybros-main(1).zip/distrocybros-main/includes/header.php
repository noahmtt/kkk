<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Détection automatique du chemin de base sur Laragon (VirtualHost ou sous-dossier localhost)
$projectRoot = str_replace('\\', '/', realpath(__DIR__ . '/..'));$docRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));$base_url = str_replace($docRoot, '',$projectRoot);
if ($base_url === '/') {$base_url = '';
}

// Connexion à la base de données `nexus.db` sur Laragon (utilisateur root par défaut sans mot de passe)
$db_host = '127.0.0.1';
$db_name = 'nexus.db';
$db_user = 'root';$db_pass = '';

try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user,$db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données nexus.db : " . htmlspecialchars($e->getMessage()));
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NexusDistro</title>
    <link rel="stylesheet" href="<?= $base_url ?>/style.css">
</head>
<body>
    <header class="navbar">
        <div class="logo-container">
            <img src="<?= $base_url ?>/Ressources/images/probeneo.png" alt="Logo Nexus" class="logo-icon">
            <a href="<?= $base_url ?>/index.php" class="logo-text" style="color: inherit; text-decoration: none;">NexusDistro</a>
        </div>

        <nav class="nav-links">
            <a href="<?= $base_url ?>/index.php" class="<?= $current_page === 'index.php' ? 'active-link' : '' ?>">Accueil</a>
            <a href="<?= $base_url ?>/pages/recherche.php" class="<?= $current_page === 'recherche.php' ? 'active-link' : '' ?>">Recherche</a>

            <?php if (isset($_SESSION['user'])): ?>
                <a href="<?= $base_url ?>/pages/favori.php" class="<?= $current_page === 'favori.php' ? 'active-link' : '' ?>">Favoris</a>
                <a href="<?= $base_url ?>/pages/profil.php" class="<?= $current_page === 'profil.php' ? 'active-link' : '' ?>">Profil (<?= htmlspecialchars($_SESSION['user']['username']) ?>)</a>
                <a href="<?= $base_url ?>/pages/contacter_admin.php" class="<?= $current_page === 'contacter_admin.php' ? 'active-link' : '' ?>">Contact</a>

                <?php if ($_SESSION['user']['role'] === 'admin'): ?>
                    <a href="<?= $base_url ?>/pages/dashboard_admin.php" class="<?= in_array($current_page, ['dashboard_admin.php', 'ajouter_distro.php', 'gestion_user.php', 'admin_backup.php']) ? 'active-link' : '' ?>">Admin</a>
                <?php endif; ?>

                <a href="<?= $base_url ?>/pages/logout.php" class="login-btn">Déconnexion</a>
            <?php else: ?>
                <a href="<?= $base_url ?>/pages/inscription.php" class="<?= $current_page === 'inscription.php' ? 'active-link' : '' ?>">Inscription</a>
                <a href="<?= $base_url ?>/pages/login.php" class="login-btn <?= $current_page === 'login.php' ? 'active-link' : '' ?>">Connexion</a>
            <?php endif; ?>
        </nav>
    </header>