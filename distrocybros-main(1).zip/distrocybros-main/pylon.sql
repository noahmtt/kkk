DROP DATABASE IF EXISTS `nexus.db`;
CREATE DATABASE IF NOT EXISTS `nexus.db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `nexus.db`;

CREATE TABLE categories (
    id_cat INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE utilisateurs (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    biographie TEXT,
    avatar VARCHAR(255) DEFAULT 'default.png',
    reset_token VARCHAR(64) DEFAULT NULL
);

CREATE TABLE distributions (
    id_distro INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    version VARCHAR(50) NOT NULL,
    id_cat INT,
    os_type VARCHAR(50) DEFAULT 'Linux',
    pays_origine VARCHAR(100) NOT NULL,
    base_sur VARCHAR(100) NOT NULL,
    environnement_bureau VARCHAR(150) NOT NULL,
    architecture VARCHAR(100) NOT NULL,
    format_paquet VARCHAR(50) NOT NULL,
    modele_publication VARCHAR(50) NOT NULL,
    taille_iso VARCHAR(50) NOT NULL,
    methode_installation VARCHAR(100) NOT NULL,
    support_multilingue VARCHAR(255) DEFAULT 'Oui',
    init_software VARCHAR(50) DEFAULT 'systemd',
    statut ENUM('Actif', 'En pause', 'Abandonné') DEFAULT 'Actif',
    description TEXT,
    lien_telechargement VARCHAR(255),
    image_logo VARCHAR(255) DEFAULT 'linux.png',
    FOREIGN KEY (id_cat) REFERENCES categories(id_cat) ON DELETE SET NULL
);

CREATE TABLE commentaires (
    id_commentaire INT AUTO_INCREMENT PRIMARY KEY,
    id_distro INT NOT NULL,
    id_user INT NOT NULL,
    contenu TEXT NOT NULL,
    date_pub DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_distro) REFERENCES distributions(id_distro) ON DELETE CASCADE,
    FOREIGN KEY (id_user) REFERENCES utilisateurs(id_user) ON DELETE CASCADE
);

CREATE TABLE evaluations (
    id_eval INT AUTO_INCREMENT PRIMARY KEY,
    id_distro INT NOT NULL,
    id_user INT NOT NULL,
    note INT CHECK (note BETWEEN 1 AND 5),
    UNIQUE(id_distro, id_user),
    FOREIGN KEY (id_distro) REFERENCES distributions(id_distro) ON DELETE CASCADE,
    FOREIGN KEY (id_user) REFERENCES utilisateurs(id_user) ON DELETE CASCADE
);

CREATE TABLE favoris (
    id_favori INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    id_distro INT NOT NULL,
    UNIQUE(id_user, id_distro),
    FOREIGN KEY (id_user) REFERENCES utilisateurs(id_user) ON DELETE CASCADE,
    FOREIGN KEY (id_distro) REFERENCES distributions(id_distro) ON DELETE CASCADE
);

CREATE TABLE messages_admin (
    id_msg INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    sujet VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_user) REFERENCES utilisateurs(id_user) ON DELETE CASCADE
);

INSERT INTO categories (nom, description) VALUES 
('Cybersécurité & Pentest', 'Distributions orientées audit de sécurité, anonymat et tests d''intrusion.'),
('Grand Public & Bureau', 'Systèmes accessibles, gaming et complets pour un usage quotidien ou avancé.'),
('Serveur & Stabilité', 'Distributions robustes conçues pour l''administration système, réseau et le cloud.'),
('Léger & Ancien Matériel', 'Systèmes optimisés et minimalistes pour les petites configurations.');

INSERT INTO distributions (
    nom, version, id_cat, os_type, pays_origine, base_sur, environnement_bureau, 
    architecture, format_paquet, modele_publication, taille_iso, methode_installation, 
    support_multilingue, init_software, statut, description, lien_telechargement, image_logo
) VALUES 
('Kali Linux', '2026.1', 1, 'Linux', 'États-Unis', 'Debian (Testing)', 'XFCE, GNOME, KDE Plasma', 'x86_64, aarch64, armhf', 'DEB', 'Rolling', '3.8 Go', 'GUI / Texte (Debian Installer)', 'Oui', 'systemd', 'Actif', 'Distribution basée sur Debian, spécialisée dans l''audit de sécurité, le forensique et le pentesting.', 'https://www.kali.org/get-kali/', 'kali.png'),
('Parrot OS', '6.1', 1, 'Linux', 'Italie', 'Debian (Stable)', 'MATE, KDE Plasma', 'x86_64, aarch64', 'DEB', 'Rolling', '2.5 Go - 4.9 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Système orienté cybersécurité, développement et vie privée, léger et doté d''outils de pentest préinstallés.', 'https://www.parrotsec.org/download/', 'parrot.png'),
('Qubes OS', '4.2.3', 1, 'Linux / Xen', 'Pologne', 'Fedora / Debian / Whonix', 'XFCE', 'x86_64', 'RPM / DEB', 'Fixed', '6.2 Go', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'Système d''exploitation ultra-sécurisé reposant sur la sécurité par compartimentation via l''hyperviseur Xen.', 'https://www.qubes-os.org/downloads/', 'qubes.png'),
('BlackArch Linux', '2026.01', 1, 'Linux', 'Global', 'Arch Linux', 'Window Managers (Fluxbox, i3, Awesome)', 'x86_64, aarch64', 'Pacman', 'Rolling', '5.2 Go (Slim) / 22 Go (Full)', 'Script CLI (blackarch-install)', 'Oui', 'systemd', 'Actif', 'Distribution basée sur Arch Linux destinée aux chercheurs en sécurité et testeurs d''intrusion avec plus de 2800 outils.', 'https://blackarch.org/downloads.html', 'blackarch.png'),
('Tails', '6.8', 1, 'Linux', 'Global', 'Debian', 'GNOME', 'x86_64', 'DEB', 'Fixed', '1.4 Go', 'Live USB uniquement', 'Oui', 'systemd', 'Actif', 'Système amnésique live conçu pour préserver la vie privée et l''anonymat en faisant passer tout le trafic par Tor.', 'https://tails.net/install/', 'tails.png'),
('Whonix', '17.2', 1, 'Linux', 'Allemagne', 'Debian', 'XFCE, CLI', 'x86_64, aarch64', 'DEB', 'Fixed', '2.1 Go', 'Import Machine Virtuelle (OVA/KVM)', 'Oui', 'systemd', 'Actif', 'Système d''exploitation axé sur l''anonymat absolu, scindé en deux machines virtuelles (Gateway Tor et Workstation).', 'https://www.whonix.org/wiki/Download', 'whonix.png'),
('Ubuntu', '24.04 LTS', 2, 'Linux', 'Île de Man / Royaume-Uni', 'Debian', 'GNOME', 'x86_64, aarch64, riscv64', 'DEB / Snap', 'LTS / Fixed', '4.7 Go', 'GUI (Flutter Installer)', 'Oui', 'systemd', 'Actif', 'Distribution conviviale et très populaire basée sur Debian, bénéficiant d''un immense écosystème.', 'https://ubuntu.com/download', 'ubuntu.png'),
('CachyOS', '2026.03', 2, 'Linux', 'Allemagne', 'Arch Linux', 'KDE Plasma, GNOME, Hyprland, XFCE', 'x86_64-v3, x86_64-v4', 'Pacman', 'Rolling', '2.6 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Distribution basée sur Arch ultra-optimisée pour la vitesse et le gaming avec des paquets compilés en x86-64-v3/v4 et des noyaux custom (BORE).', 'https://cachyos.org/download/', 'cachyos.png'),
('Arch Linux', 'Rolling', 2, 'Linux', 'Canada', 'Indépendante', 'Au choix (Aucun par défaut)', 'x86_64', 'Pacman', 'Rolling', '1.1 Go', 'Texte (CLI / archinstall)', 'Oui', 'systemd', 'Actif', 'Distribution minimaliste, flexible et indépendante suivant le principe KISS, où l''utilisateur construit son système sur mesure.', 'https://archlinux.org/download/', 'arch.png'),
('Linux Mint', '22 (Wilma)', 2, 'Linux', 'Irlande', 'Ubuntu / Debian', 'Cinnamon, MATE, XFCE', 'x86_64', 'DEB / Flatpak', 'LTS', '2.9 Go', 'GUI (Ubiquity)', 'Oui', 'systemd', 'Actif', 'Système élégant, stable et intuitif, particulièrement recommandé pour les utilisateurs venant de Windows.', 'https://linuxmint.com/download.php', 'mint.png'),
('Fedora Workstation', '41', 2, 'Linux', 'États-Unis', 'Indépendante', 'GNOME, KDE Plasma, Sway', 'x86_64, aarch64, ppc64le', 'RPM / Flatpak', 'Fixed', '2.3 Go', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'Distribution innovante soutenue par Red Hat, intégrant les dernières technologies libres (Wayland, PipeWire) tout en restant stable.', 'https://fedoraproject.org/workstation/download', 'fedora.png'),
('Pop!_OS', '24.04 LTS', 2, 'Linux', 'États-Unis', 'Ubuntu', 'COSMIC', 'x86_64, aarch64', 'DEB / Flatpak', 'LTS / Fixed', '2.8 Go', 'GUI (Pop Installer)', 'Oui', 'systemd', 'Actif', 'Développée par System76 avec son nouvel environnement COSMIC en Rust, pensée pour les développeurs, créatifs et joueurs.', 'https://pop.system76.com/', 'popos.png'),
('Manjaro', '24.1', 2, 'Linux', 'Allemagne', 'Arch Linux', 'KDE Plasma, XFCE, GNOME', 'x86_64, aarch64', 'Pacman / Flatpak / Snap', 'Rolling', '3.6 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Rend la puissance d''Arch Linux accessible avec un installateur graphique, une détection matérielle automatique et des dépôts temporisés.', 'https://manjaro.org/download/', 'manjaro.png'),
('Zorin OS', '17.2', 2, 'Linux', 'Irlande', 'Ubuntu', 'GNOME (Zorin Desktop)', 'x86_64', 'DEB / Flatpak', 'LTS', '3.4 Go', 'GUI (Ubiquity)', 'Oui', 'systemd', 'Actif', 'Alternative directe à Windows et macOS dotée d''une interface adaptable et d''une prise en charge native facilitée des logiciels Windows.', 'https://zorin.com/os/download/', 'zorin.png'),
('EndeavourOS', '2026.01', 2, 'Linux', 'Pays-Bas', 'Arch Linux', 'KDE Plasma, XFCE, i3, GNOME', 'x86_64, aarch64', 'Pacman', 'Rolling', '2.7 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Héritière spirituelle d''Antergos offrant une expérience Arch Linux quasi pure avec une installation graphique rapide et une communauté très active.', 'https://endeavouros.com/', 'endeavouros.png'),
('Bazzite', '41', 2, 'Linux', 'États-Unis', 'Fedora (Universal Blue)', 'KDE Plasma, GNOME (Steam Game Mode)', 'x86_64', 'rpm-ostree / Flatpak', 'Rolling', '4.5 Go', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'Système immuable basé sur Fedora atomique, conçu spécifiquement pour le gaming sur PC et consoles portables (type Steam Deck).', 'https://bazzite.gg/', 'bazzite.png'),
('Debian', '12 (Bookworm)', 3, 'Linux', 'Global', 'Indépendante', 'GNOME, KDE, XFCE, Aucun (Serveur)', 'x86_64, aarch64, armhf, i386, riscv64', 'DEB', 'Fixed', '630 Mo (Netinst) - 3.9 Go', 'GUI / Texte (Debian Installer)', 'Oui', 'systemd', 'Actif', 'Système d''exploitation universel reconnu pour son extrême stabilité, sa sécurité et son contrat social rigoureux.', 'https://www.debian.org/distrib/', 'debian.png'),
('Rocky Linux', '9.5', 3, 'Linux', 'États-Unis', 'Red Hat Enterprise Linux', 'GNOME, Minimal CLI', 'x86_64, aarch64, ppc64le, s390x', 'RPM', 'LTS', '1.8 Go (Minimal) - 10 Go (DVD)', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'Système d''entreprise communautaire conçu pour être 100 % compatible binaire avec Red Hat Enterprise Linux, fondé par le créateur de CentOS.', 'https://rockylinux.org/download', 'rocky.png'),
('AlmaLinux', '9.5', 3, 'Linux', 'États-Unis', 'Red Hat Enterprise Linux', 'GNOME, Minimal CLI', 'x86_64, aarch64, ppc64le, s390x', 'RPM', 'LTS', '1.7 Go (Minimal) - 9.8 Go (DVD)', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'Distribution serveur de classe entreprise compatible ABI avec RHEL, gérée par une fondation à but non lucratif.', 'https://almalinux.org/get-almalinux/', 'almalinux.png'),
('openSUSE Leap', '15.6', 3, 'Linux', 'Allemagne', 'SUSE Linux Enterprise (SLE)', 'KDE Plasma, GNOME, XFCE', 'x86_64, aarch64, ppc64le', 'RPM', 'Fixed / LTS', '4.3 Go', 'GUI / Texte (YaST)', 'Oui', 'systemd', 'Actif', 'Distribution ultra-stable partageant son code source avec SUSE Linux Enterprise, équipée du puissant centre de contrôle YaST.', 'https://get.opensuse.org/leap/', 'opensuse.png'),
('Red Hat Enterprise Linux', '9.5', 3, 'Linux', 'États-Unis', 'Fedora', 'GNOME, CLI', 'x86_64, aarch64, ppc64le, s390x', 'RPM', 'LTS', '9.5 Go', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'La référence mondiale des systèmes d''exploitation Linux commerciaux pour les datacenters, le cloud hybride et les infrastructures critiques.', 'https://developers.redhat.com/products/rhel/download', 'rhel.png'),
('NixOS', '24.11', 3, 'Linux', 'Pays-Bas', 'Indépendante', 'KDE Plasma, GNOME, Aucun', 'x86_64, aarch64', 'Nix', 'Fixed / Rolling', '1.0 Go - 2.6 Go', 'GUI (Calamares) / Déclaratif CLI', 'Oui', 'systemd', 'Actif', 'Distribution unique reposant sur une configuration entièrement déclarative et reproductible, avec des mises à jour atomiques sans risque de panne.', 'https://nixos.org/download/', 'nixos.png'),
('Slackware', '15.0', 3, 'Linux', 'États-Unis', 'Indépendante', 'KDE Plasma, XFCE', 'x86_64, i586', 'txz / pkgtools', 'Fixed', '3.6 Go', 'Texte (ncurses)', 'Oui', 'sysvinit', 'Actif', 'La plus ancienne distribution Linux encore en activité, célèbre pour sa simplicité de type Unix et l''absence de résolution automatique de dépendances.', 'http://www.slackware.com/getslack/', 'slackware.png'),
('Lubuntu', '24.04 LTS', 4, 'Linux', 'Global', 'Ubuntu', 'LXQt', 'x86_64', 'DEB / Snap', 'LTS / Fixed', '3.1 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Variante officielle d''Ubuntu utilisant l''environnement de bureau léger LXQt, peu gourmande en RAM et CPU.', 'https://lubuntu.me/downloads/', 'lubuntu.png'),
('Alpine Linux', '3.21', 4, 'Linux', 'Global', 'Indépendante', 'Aucun (CLI), XFCE/GNOME en option', 'x86_64, aarch64, x86, armhf, riscv64', 'APK', 'Fixed', '180 Mo', 'Texte (setup-alpine)', 'Non (Anglais par défaut)', 'OpenRC', 'Actif', 'Distribution ultra-légère et sécurisée utilisant musl libc et BusyBox, incontournable pour les conteneurs Docker et les systèmes embarqués.', 'https://alpinelinux.org/downloads/', 'alpine.png'),
('MX Linux', '23.4', 4, 'Linux', 'États-Unis / Grèce', 'Debian (Stable)', 'XFCE, KDE Plasma, Fluxbox', 'x86_64, i386 (32-bit)', 'DEB', 'Semi-rolling', '2.2 Go', 'GUI (Gazelle Installer)', 'Oui', 'sysvinit (systemd en option)', 'Actif', 'Système de poids moyen combinant un bureau élégant et réactif avec une configuration simple et les outils maison MX Tools.', 'https://mxlinux.org/download-links/', 'mxlinux.png'),
('Void Linux', 'Rolling', 4, 'Linux', 'Global', 'Indépendante', 'XFCE, Base CLI', 'x86_64, aarch64, armv7l (glibc / musl)', 'XBPS', 'Rolling', '800 Mo - 1.3 Go', 'Texte (ncurses void-installer)', 'Oui', 'runit', 'Actif', 'Distribution indépendante rapide et minimaliste utilisant le système d''init runit et le gestionnaire de paquets ultra-rapide XBPS.', 'https://voidlinux.org/download/', 'void.png'),
('antiX', '23.2', 4, 'Linux', 'Grèce', 'Debian', 'IceWM, Fluxbox, JWM', 'x86_64, i386 (32-bit)', 'DEB', 'Fixed', '1.6 Go (Full) / 250 Mo (Net)', 'GUI / Texte', 'Oui', 'sysvinit / runit', 'Actif', 'Distribution extrêmement légère totalement dépourvue de systemd, capable de redonner vie à de très vieux ordinateurs (dès 256 Mo de RAM).', 'https://antixlinux.com/download/', 'antix.png'),
('Puppy Linux', '9.5 (FossaPup64)', 4, 'Linux', 'Australie', 'Ubuntu / Slackware', 'JWM (Joe''s Window Manager)', 'x86_64, i386', 'PET / DEB', 'Fixed', '400 Mo', 'Live RAM / Frugal Install', 'Oui', 'BusyBox init', 'Actif', 'Minuscule distribution qui se charge intégralement dans la mémoire vive (RAM) au démarrage pour une réactivité instantanée.', 'https://puppylinux-woof-ce.github.io/', 'puppy.png'),
('Bodhi Linux', '7.0', 4, 'Linux', 'États-Unis', 'Ubuntu (LTS)', 'Moksha (Enlightenment fork)', 'x86_64', 'DEB', 'LTS', '1.3 Go', 'GUI (Ubiquity)', 'Oui', 'systemd', 'Actif', 'Distribution minimaliste utilisant le bureau Moksha, offrant une esthétique unique et fluide avec une empreinte mémoire minime.', 'https://www.bodhilinux.com/download/', 'bodhi.png'),
('Athena OS', '2023.1', 1, 'Linux', 'Italie', 'Arch Linux', 'GNOME', 'x86_64', 'Pacman', 'Rolling', '3.5 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Distribution moderne de pentesting et d''infosec basée sur Arch Linux, avec une forte intégration communautaire.', 'https://athenaos.org/download/', 'athena.png'),
('elementary OS', '7.1', 2, 'Linux', 'États-Unis', 'Ubuntu', 'Pantheon', 'x86_64', 'DEB / Flatpak', 'Fixed', '3.0 Go', 'GUI (Installer)', 'Oui', 'systemd', 'Actif', 'Système élégant, rapide et respectueux de la vie privée, souvent considéré comme l''alternative Linux la plus aboutie visuellement.', 'https://elementary.io/', 'elementary.png'),
('KDE Neon', '202403', 2, 'Linux', 'Royaume-Uni', 'Ubuntu LTS', 'KDE Plasma', 'x86_64', 'DEB / Flatpak / Snap', 'Semi-rolling', '2.8 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'La vitrine technologique officielle de KDE, offrant la toute dernière version du bureau Plasma sur une base stable.', 'https://neon.kde.org/download', 'kdeneon.png'),
('Deepin', '23', 2, 'Linux', 'Chine', 'Debian', 'DDE (Deepin Desktop Environment)', 'x86_64', 'DEB', 'Fixed', '4.5 Go', 'GUI', 'Oui', 'systemd', 'Actif', 'Distribution reconnue pour son interface magnifique et intuitive, offrant une expérience utilisateur très soignée dès l''installation.', 'https://www.deepin.org/en/download/', 'deepin.png'),
('Nobara Linux', '39', 2, 'Linux', 'Global', 'Fedora', 'KDE Plasma, GNOME', 'x86_64', 'RPM / Flatpak', 'Fixed', '3.2 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Système optimisé spécifiquement pour le gaming et la création de contenu avec des correctifs noyaux et pilotes préinstallés.', 'https://nobaraproject.org/download/', 'nobara.png'),
('Garuda Linux', 'Dr460nized', 2, 'Linux', 'Inde', 'Arch Linux', 'KDE Plasma, GNOME, XFCE', 'x86_64', 'Pacman', 'Rolling', '3.1 Go', 'GUI (Calamares)', 'Oui', 'systemd', 'Actif', 'Distribution basée sur Arch très esthétique, axée sur les performances brutes (kernel Zen, BTRFS) et le jeu vidéo.', 'https://garudalinux.org/downloads.html', 'garuda.png'),
('Proxmox VE', '8.1', 3, 'Linux', 'Autriche', 'Debian', 'Interface Web', 'x86_64', 'DEB', 'Fixed', '1.2 Go', 'GUI (Proxmox Installer)', 'Oui', 'systemd', 'Actif', 'Plateforme open source bare-metal pour la virtualisation d''infrastructure, intégrant l''hyperviseur KVM et les conteneurs LXC.', 'https://www.proxmox.com/en/downloads', 'proxmox.png'),
('CentOS Stream', '9', 3, 'Linux', 'États-Unis', 'Upstream RHEL', 'GNOME, CLI', 'x86_64, aarch64, ppc64le', 'RPM', 'Rolling (Release)', '9.0 Go', 'GUI (Anaconda)', 'Oui', 'systemd', 'Actif', 'Distribution de développement en continu se situant entre Fedora et Red Hat Enterprise Linux, idéale pour les environnements de test.', 'https://www.centos.org/download/', 'centos.png'),
('Gentoo Linux', 'Rolling', 3, 'Linux', 'États-Unis', 'Indépendante', 'Au choix', 'x86_64, aarch64, arm', 'Portage', 'Rolling', '400 Mo', 'Texte (CLI)', 'Oui', 'OpenRC / systemd', 'Actif', 'Distribution pour utilisateurs avancés où chaque composant est compilé localement depuis le code source pour une optimisation matérielle absolue.', 'https://www.gentoo.org/downloads/', 'gentoo.png'),
('Linux Lite', '6.6', 4, 'Linux', 'Nouvelle-Zélande', 'Ubuntu LTS', 'XFCE', 'x86_64', 'DEB', 'Fixed', '2.4 Go', 'GUI (Ubiquity)', 'Oui', 'systemd', 'Actif', 'Système léger et convivial conçu spécifiquement pour faciliter la transition en douceur des utilisateurs vers le monde Linux.', 'https://www.linuxliteos.com/download.php', 'linuxlite.png');
-- Mot de passe des comptes par défaut : Password123!
INSERT INTO utilisateurs (id_user, username, email, password, role, biographie, avatar) VALUES 
(NULL, 'florent', 'florent@distro-linux.local', '2c103f2c4ed1e59c0b4e2e01821770fa', 'user', 'le mec il est user', 'florent.jpg'),
(NULL, 'noah', 'noah@nexusdistro.local', '5b91ab720c6f3863e71f00ec1443adbe', 'user', 'verneuille', 'noah.png'),
(NULL, 'bastien', 'bastien@distro-linux.local', '2c103f2c4ed1e59c0b4e2e01821770fa', 'user', 'Compte utilisateur de Bastien', 'bastien.png'),
(NULL, 'user', 'user@distro-linux.local', '2c103f2c4ed1e59c0b4e2e01821770fa', 'user', 'Compte de test standard', 'default.png'),

-- les deux comptes admin avec un id haut pour l'idor
(4829, 'admin', 'admin@distro-linux.local', '2c103f2c4ed1e59c0b4e2e01821770fa', 'admin', 'Administrateur principal du catalogue Linux.', 'default.png'),
(8342, 'hexalos', 'hexalos@nexusdistro.local', '5b91ab720c6f3863e71f00ec1443adbe', 'admin', 'Utilisateur secret' , 'hexalos.jpg');
