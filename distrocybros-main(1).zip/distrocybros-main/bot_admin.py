from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
import re
import html

# 1. Configuration des options Headless pour exécution par Apache (www-data)
options = Options()
options.add_argument("--headless") 
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")

# 🔴 LES OPTIONS MAGIQUES POUR LE SERVEUR WEB (www-data) 🔴
# On force Chrome à utiliser /tmp pour écrire ses fichiers locaux
options.add_argument("--user-data-dir=/tmp/chrome-data")
options.add_argument("--data-path=/tmp/chrome-data")
options.add_argument("--disk-cache-dir=/tmp/chrome-cache")
options.add_argument("--crash-dumps-dir=/tmp/chrome-crash")
options.add_argument("--remote-debugging-port=9222") # Évite certains crashs de démarrage

# 2. Indication explicite du chemin du driver
service = Service('/usr/bin/chromedriver')

print("Lancement du Bot...")
driver = webdriver.Chrome(service=service, options=options)
driver.implicitly_wait(2)

try:
    print("Navigation vers la page de connexion...")
    driver.get("http://10.0.2.4/pages/login.php")

    print("Entrée de l'identifiant de l'admin...")
    username_input = driver.find_element(By.NAME, "identifiant")
    username_input.clear()
    username_input.send_keys("admin")

    print("Entrée du mot de passe de l'admin...")
    password_input = driver.find_element(By.NAME, "password")
    password_input.clear()
    password_input.send_keys("Password123!")

    print("Connexion...")
    bouton_submit = driver.find_element(By.CSS_SELECTOR, ".tab-btn.active")
    bouton_submit.click()

    time.sleep(1)

    if "login" not in driver.current_url:
        print("Bot Connecté en tant qu'Admin")
        liens_deja_visites = []

        # Scan du Dashboard
        driver.get("http://10.0.2.4/pages/dashboard_admin.php")
        print("Scan de la page...")
        time.sleep(2)

        texte_page = driver.page_source
        pattern = r"(http://10\.0\.2\.4/pages/evaluer_distro\.php\?id=[^\"<\s]+)"
        liens_trouves = re.findall(pattern, texte_page)

        for url_trouvee in liens_trouves:
            url_trouvee = html.unescape(url_trouvee.strip())
            if url_trouvee not in liens_deja_visites:
                print(f"[!] Lien détecté : {url_trouvee}")
                driver.get(url_trouvee)
                print("Consultation de la page en cours...")
                time.sleep(3)
                liens_deja_visites.append(url_trouvee)
    else:
        print("Échec de la connexion de l'admin.")

except Exception as e:
    print(f"Erreur durant l'exécution : {e}")

finally:
    print("Fermeture du bot.")
    driver.quit()
