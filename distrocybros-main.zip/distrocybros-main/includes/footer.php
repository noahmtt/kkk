<footer class="options-section">
        <p class="comment"># NexusDistro — Plateforme d'exploration et d'évaluation de distributions GNU/Linux</p>
        <br>
    </footer>
</body>
</html>