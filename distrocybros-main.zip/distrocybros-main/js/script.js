document.addEventListener('DOMContentLoaded', () => {
    const themeBtn = document.getElementById('theme-toggle');
    const infoBox = document.getElementById('dom-info-box');

    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            themeBtn.textContent = isDark ? 'Mode Clair' : 'Mode Sombre';
            
            if (infoBox) {
                infoBox.innerHTML = `<p><strong>DOM mis à jour :</strong> Thème <em>${isDark ? 'Sombre' : 'Clair'}</em> activé à ${new Date().toLocaleTimeString()}.</p>`;
            }
        });
    }

    const quickFilter = document.getElementById('quick-dom-filter');
    if (quickFilter) {
        quickFilter.addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            document.querySelectorAll('.distro-card').forEach(card => {
                const title = card.querySelector('h3').textContent.toLowerCase();
                card.style.display = title.includes(term) ? 'block' : 'none';
            });
        });
    }
});
