<?php
require_once __DIR__ . '/../includes/header.php';

// [VULNÉRABILITÉ FORCED BROWSING - CWE-425]
// Oubli volontaire de la vérification du rôle admin :
// if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') { ... }

// [PROTECTION ANTI-SQLMAP] (Exigence du document de cadrage)
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (stripos($user_agent, 'sqlmap') !== false) {
    http_response_code(403);
    die("<div class='container'><div class='terminal-mockup' style='border-color: #ff4b4b; color: #ff4b4b;'>
        [!] ALERTE IDS : Outil automatisé (sqlmap) détecté.<br>
        Ce challenge doit être résolu à l'aide d'un script personnalisé (Python ou Bash).
    </div></div>");
}

$check_result = null;
$searched_user = '';

// Traitement du formulaire (compatible POST et GET pour faciliter ou orienter vos tests)
if (isset($_POST['username_check']) && $_POST['username_check'] !== '') {
    $searched_user = $_POST['username_check'];

    // [VULNÉRABILITÉ SQLi BOOLEAN BLIND - CWE-89]
    // Concaténation directe de l'entrée utilisateur sans requête préparée
    $sql = "SELECT id_user FROM utilisateurs WHERE username = '$searched_user'";

    try {
        $stmt = $pdo->query($sql);
        // On ne récupère aucune donnée à afficher : on vérifie seulement si au moins 1 ligne existe
        if ($stmt && $stmt->fetch()) {
            $check_result = true;
        } else {
            $check_result = false;
        }
    } catch (PDOException $e) {
        // On masque l'erreur SQL pour empêcher les attaques Error-Based et forcer le Blind
        $check_result = false;
    }
}
?>

<div class="container">
    <!-- Fil d'Ariane -->
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/dashboard_admin.php">Administration</a> / Utilitaire de Backup SQL
    </div>

    <!-- Section Hero -->
    <section class="hero">
        <div class="hero-content">
            <h1>Utilitaire de Backup SQL</h1>
            <h2>Outil de maintenance et de vérification d'intégrité de la base <code>nexus.db</code>.</h2>
            <p>
                Cet utilitaire interne permet aux administrateurs de vérifier l'intégrité des enregistrements 
                dans la table <code>utilisateurs</code> avant de générer une archive de sauvegarde SQL complète.
            </p>
            <ul>
                <li>Base cible : <strong>nexus.db</strong></li>
                <li>Table auditée : <strong>utilisateurs</strong></li>
                <li>Export complet (<code>mysqldump</code>) : <strong>Désactivé (Maintenance en cours)</strong></li>
            </ul>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">backup-daemon@nexusdistro</span>:~# ./nexus-backup --status</p>
                <br>
                <p>[*] Service : NexusBackup v1.4 (Legacy)</p>
                <p>[*] Connexion MySQL : Active</p>
                <p>[!] Note : N'oubliez pas de restreindre l'accès à cette page avant la mise en production.</p>
                <br>
                <?php if ($check_result === true): ?>
                    <p style="color: #4ade80; font-weight: bold;">
                        [STATUS: OK] L'utilisateur existe dans la base nexus.db. Enregistrement intègre et prêt pour l'export SQL.
                    </p>
                <?php elseif ($check_result === false): ?>
                    <p style="color: #f87171; font-weight: bold;">
                        [STATUS: ERR] L'utilisateur n'existe pas dans la base ou l'enregistrement est introuvable.
                    </p>
                <?php else: ?>
                    <p style="color: #9ca3af;">
                        [STATUS: IDLE] En attente d'une vérification d'intégrité...
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Section Formulaire de vérification (Point d'entrée Blind SQLi) -->
    <section class="options-section">
        <h2 class="section-title">Vérification d'existence avant sauvegarde (Pre-Flight Check)</h2>
        
        <div class="code-block" style="max-width: 650px; margin: 0 auto;">
            <p style="margin-bottom: 18px; color: var(--text-secondary);">
                Saisissez le nom d'utilisateur (<code>username</code>) à vérifier dans la base de données avant de lancer une tâche d'archivage :
            </p>

            <form method="POST" action="" style="display: flex; gap: 12px; flex-wrap: wrap;">
                <input 
                    type="text" 
                    name="username_check" 
                    placeholder="Ex: admin, florent..." 
                     required
                    style="flex: 1; min-width: 240px; padding: 10px 14px; background: #0a0b12; border: 1px solid var(--border-color); color: var(--text-main); border-radius: 4px; font-family: monospace;"
                >
                <button type="submit" class="tab-btn active" style="border-radius: 4px;">
                    Vérifier l'intégrité
                </button>
            </form>

            <?php if ($check_result === true): ?>
                <div style="margin-top: 20px; padding: 12px; border-left: 3px solid #4ade80; background: rgba(74, 222, 128, 0.08);">
                    <strong>Résultat :</strong> L'utilisateur est déjà créé et présent dans la base.
                </div>
            <?php elseif ($check_result === false): ?>
                <div style="margin-top: 20px; padding: 12px; border-left: 3px solid #f87171; background: rgba(248, 113, 113, 0.08);">
                    <strong>Résultat :</strong> L'utilisateur n'existe pas dans la base.
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>