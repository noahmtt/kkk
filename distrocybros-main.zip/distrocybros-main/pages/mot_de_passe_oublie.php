<?php
require_once __DIR__ . '/../includes/header.php';

$info = '';
$erreur = '';
$token_genere = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Étape 1 : Demande de jeton
    if (isset($_POST['email_reset'])) {
        $email = trim($_POST['email_reset']);
        $stmt = $pdo->prepare("SELECT id_user FROM utilisateurs WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $token_genere = bin2hex(random_bytes(16));
            $upd = $pdo->prepare("UPDATE utilisateurs SET reset_token = ? WHERE id_user = ?");
            $upd->execute([$token_genere, $user['id_user']]);
            $info = "Jeton de réinitialisation généré dans la base nexus.db.";
        } else {
            $erreur = "Aucun compte trouvé avec cette adresse email.";
        }
    }

    // Étape 2 : Validation du nouveau mot de passe via le jeton
    if (isset($_POST['token'], $_POST['new_password'])) {
        $token = trim($_POST['token']);
        $new_pass = $_POST['new_password'];

        $stmt = $pdo->prepare("SELECT id_user FROM utilisateurs WHERE reset_token = ? AND reset_token IS NOT NULL");
        $stmt->execute([$token]);
        $user = $stmt->fetch();

        if ($user && $new_pass !== '') {
            $hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $upd = $pdo->prepare("UPDATE utilisateurs SET password = ?, reset_token = NULL WHERE id_user = ?");
            $upd->execute([$hash, $user['id_user']]);
            $info = "Mot de passe mis à jour avec succès ! Vous pouvez vous connecter.";
        } else {
            $erreur = "Jeton invalide ou expiré.";
        }
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/login.php">Connexion</a> / Mot de passe oublié
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Récupération de compte</h1>
            <h2>Générez un jeton de sécurité pour réinitialiser votre mot de passe sur NexusDistro.</h2>
            <?php if ($info): ?>
                <p class="white-text">[+] <?= htmlspecialchars($info) ?></p>
            <?php endif; ?>
            <?php if ($erreur): ?>
                <p class="white-text">[!] <?= htmlspecialchars($erreur) ?></p>
            <?php endif; ?>
            <?php if ($token_genere): ?>
                <div class="code-block">
                    <p class="comment"># Jeton généré (reset_token) :</p>
                    <p class="white-text"><?= htmlspecialchars($token_genere) ?></p>
                </div>
            <?php endif; ?>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">auth@nexusdistro</span>:~$ passwd --request-token</p>
                <br>
                <form method="POST" action="">
                    <p><label>Votre adresse Email :</label></p>
                    <p><input type="email" name="email_reset" class="tab-btn" required></p>
                    <br>
                    <button type="submit" class="tab-btn active">Générer un jeton</button>
                </form>
                <br><hr><br>
                <p><span class="cyan-link">auth@nexusdistro</span>:~$ passwd --apply-token</p>
                <br>
                <form method="POST" action="">
                    <p><label>Jeton de réinitialisation :</label></p>
                    <p><input type="text" name="token" value="<?= htmlspecialchars($token_genere) ?>" class="tab-btn" required></p>
                    <br>
                    <p><label>Nouveau mot de passe :</label></p>
                    <p><input type="password" name="new_password" class="tab-btn" required></p>
                    <br>
                    <button type="submit" class="tab-btn active">Changer le mot de passe</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>