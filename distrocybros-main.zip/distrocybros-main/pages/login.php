<?php
require_once __DIR__ . '/../includes/header.php';

$erreur = '';

// --- TRAITEMENT DU FORMULAIRE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $password = $_POST['password'] ?? '';
    $posted_token = $_POST['csrf_token'] ?? '';
    $session_token = $_SESSION['csrf_token'] ?? '';

    // 1. Vérification du Token CSRF
    // Si le token envoyé ne correspond pas au token en session, on bloque.
    if (empty($session_token) || !hash_equals($session_token, $posted_token)) {
        $erreur = "Erreur de sécurité : Jeton CSRF invalide ou expiré.";
    } 
    // 2. Vérification des identifiants
    elseif ($identifiant && $password) {
        
        // VULNÉRABILITÉ INTENTIONNELLE (CWE-307) : 
        // Il n'y a aucun système de verrouillage (lockout) ni aucun délai (sleep).
        // La requête est exécutée instantanément, permettant des milliers d'essais à la suite.
        
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE username = :id OR email = :id LIMIT 1");
        $stmt->execute(['id' => $identifiant]);
        $user = $stmt->fetch();

        // Gestion du mot de passe par défaut (Password123!) pour la démo
        $defaultSeedHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
        $isValid = false;
         if ($user) {
            // VULNÉRABILITÉ INTENTIONNELLE (CWE-328) : Utilisation de MD5
            if (md5($password) === $user['password']) {
                $isValid = true;
            }
        }

        if ($isValid) {
            $_SESSION['user'] = [
                'id_user' => $user['id_user'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'avatar' => $user['avatar']
            ];
            header("Location: {$base_url}/index.php");
            exit;
        } else {
            $erreur = "Identifiants incorrects.";
        }
    } else {
        $erreur = "Veuillez remplir tous les champs.";
    }
}

// token crsf qui doit marcher jpense
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Connexion
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Connexion à NexusDistro</h1>
            <h2>Accédez à votre espace personnel pour évaluer les distributions et gérer vos favoris.</h2>
            <p>Comptes de démonstration disponibles :</p>
            <ul>
                <li><strong>admin</strong> (Mot de passe : <code>Password123!</code>)</li>
                <li><strong>florent</strong> (Mot de passe : <code>Password123!</code>)</li>
            </ul>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">auth@nexusdistro</span>:~$ login --interactive</p>
                <br>
                <?php if ($erreur): ?>
                    <p class="white-text">[!] Erreur : <?= htmlspecialchars($erreur) ?></p>
                    <br>
                <?php endif; ?>

                <form method="POST" action="">
                    <!-- Champ caché contenant le Token CSRF dynamique -->
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

                    <p><label for="identifiant">Nom d'utilisateur ou Email :</label></p>
                    <p><input type="text" id="identifiant" name="identifiant" class="tab-btn" required></p>
                    <br>
                    <p><label for="password">Mot de passe :</label></p>
                    <p><input type="password" id="password" name="password" class="tab-btn" required></p>
                    <br>
                    <button type="submit" class="tab-btn active">Se connecter</button>
                </form>
                <br>
                <p>
                    <a href="<?= $base_url ?>/pages/mot_de_passe_oublie.php" class="cyan-link">Mot de passe oublié ?</a> | 
                    <a href="<?= $base_url ?>/pages/inscription.php" class="cyan-link">Créer un compte</a>
                </p>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>