<?php
require_once __DIR__ . '/../includes/header.php';

$q = trim($_GET['q'] ?? '');
$cat = (int)($_GET['cat'] ?? 0);

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom ASC")->fetchAll();

$sql = "SELECT d.*, c.nom AS categorie, COALESCE(AVG(e.note), 0) AS moyenne
        FROM distributions d
        LEFT JOIN categories c ON d.id_cat = c.id_cat
        LEFT JOIN evaluations e ON d.id_distro = e.id_distro
        WHERE 1=1";
$params = [];

if ($q !== '') {
    $sql .= " AND (d.nom LIKE :q OR d.description LIKE :q OR d.version LIKE :q)";
    $params['q'] = "%{$q}%";
}
if ($cat > 0) {
    $sql .= " AND d.id_cat = :cat";
    $params['cat'] = $cat;
}

$sql .= " GROUP BY d.id_distro ORDER BY d.nom ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$resultats = $stmt->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Recherche de distributions
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Explorer NexusDistro</h1>
            <h2>Recherchez une distribution par nom, mot-clé ou catégorie d'utilisation.</h2>
            <p><?= count($resultats) ?> distribution(s) trouvée(s) dans la base.</p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-search --query</p>
                <br>
                <form method="GET" action="">
                    <p><input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Ex: Kali, Debian, LTS..." class="tab-btn"></p>
                    <br>
                    <p>
                        <select name="cat" class="tab-btn">
                            <option value="0">-- Toutes les catégories --</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id_cat'] ?>" <?= $cat === (int)$c['id_cat'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </p>
                    <br>
                    <button type="submit" class="tab-btn active">Lancer la recherche</button>
                    <a href="<?= $base_url ?>/pages/recherche.php" class="cyan-link">Réinitialiser</a>
                </form>
            </div>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Filtrer par catégorie</h2>
        <div class="tabs-container">
            <a href="<?= $base_url ?>/pages/recherche.php" class="tab-btn <?= $cat === 0 ? 'active' : '' ?>">Toutes</a>
            <?php foreach ($categories as $c): ?>
                <a href="<?= $base_url ?>/pages/recherche.php?cat=<?= (int)$c['id_cat'] ?>&q=<?= urlencode($q) ?>" class="tab-btn <?= $cat === (int)$c['id_cat'] ? 'active' : '' ?>">
                    <?= htmlspecialchars($c['nom']) ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- Grille de résultats en vignettes -->
        <div class="neofetch-grid" style="text-align: left;">
            <?php foreach ($resultats as $d): 
                $hostname = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $d['nom']));
            ?>
                <article class="neofetch-card">
                    <!-- Colonne Gauche : Uniquement le gros logo -->
                    <div class="neofetch-left">
                        <div class="neofetch-logo-box">
                            <?php if (!empty($d['image_logo'])): ?>
                                <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($d['image_logo']) ?>" alt="Logo <?= htmlspecialchars($d['nom']) ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Colonne Droite : Toutes les colonnes de la table distributions -->
                    <div class="neofetch-right">
                        <div class="neofetch-user-host">
                            user<span>@</span><?= htmlspecialchars($hostname) ?>
                        </div>
                        <div class="neofetch-separator">-------------------</div>

                        <ul class="neofetch-specs">
                            <li><span class="neofetch-label">Nom:</span> <?= htmlspecialchars($d['nom']) ?> (<?= htmlspecialchars($d['version']) ?>)</li>
                            <li><span class="neofetch-label">Catégorie:</span> <?= htmlspecialchars($d['categorie'] ?? 'Non classé') ?> | <span class="neofetch-label">Note:</span> <?= number_format((float)$d['moyenne'], 1) ?>/5</li>
                            <li><span class="neofetch-label">Type de l'OS:</span> <?= htmlspecialchars($d['os_type'] ?? 'Linux') ?></li>
                            <li><span class="neofetch-label">Pays:</span> <?= htmlspecialchars($d['pays_origine'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Basé sur:</span> <?= htmlspecialchars($d['base_sur'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Environnement bureau:</span> <?= htmlspecialchars($d['environnement_bureau'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Architecture:</span> <?= htmlspecialchars($d['architecture'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Format paquet:</span> <?= htmlspecialchars($d['format_paquet'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Modèle publication:</span> <?= htmlspecialchars($d['modele_publication'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Taille ISO:</span> <?= htmlspecialchars($d['taille_iso'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Mode d'installation:</span> <?= htmlspecialchars($d['methode_installation'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Support multilingue:</span> <?= htmlspecialchars($d['support_multilingue'] ?? 'Oui') ?></li>
                            <li><span class="neofetch-label">Init software:</span> <?= htmlspecialchars($d['init_software'] ?? 'systemd') ?></li>
                            <li><span class="neofetch-label">Statut:</span> <?= htmlspecialchars($d['statut'] ?? 'Actif') ?></li>
                        </ul>

                        <!-- Palette de couleurs + Actions -->
                        <div class="neofetch-Footer">
                            <div class="neofetch-palette">
                                <span class="pal-1"></span>
                                <span class="pal-2"></span>
                                <span class="pal-3"></span>
                                <span class="pal-4"></span>
                                <span class="pal-5"></span>
                                <span class="pal-6"></span>
                                <span class="pal-7"></span>
                                <span class="pal-8"></span>
                            </div>

                            <div class="neofetch-actions">
                                <a href="<?= $base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="neofetch-btn">Voir la fiche complète →</a>
                                <?php if (!empty($d['lien_telechargement'])): ?>
                                    <a href="<?= htmlspecialchars($d['lien_telechargement']) ?>" target="_blank" rel="noopener" class="neofetch-btn">[ ISO ↗ ]</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>