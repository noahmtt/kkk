<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

$id_user = (int)$_SESSION['user']['id_user'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $biographie = trim($_POST['biographie'] ?? '');
    $avatar = trim($_POST['avatar'] ?? 'default.png');
    $new_password = $_POST['new_password'] ?? '';

    if ($email !== '') {
        $upd = $pdo->prepare("UPDATE utilisateurs SET email = ?, biographie = ?, avatar = ? WHERE id_user = ?");
        $upd->execute([$email, $biographie, $avatar, $id_user]);

        if ($new_password !== '') {
            $hash = password_hash($new_password, PASSWORD_BCRYPT);
            $updPass = $pdo->prepare("UPDATE utilisateurs SET password = ? WHERE id_user = ?");
            $updPass->execute([$hash, $id_user]);
        }

        $_SESSION['user']['email'] = $email;
        $_SESSION['user']['avatar'] = $avatar;
        $message = "Votre profil a été mis à jour avec succès.";
    }
}

$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id_user = ?");
$stmt->execute([$id_user]);
$profil = $stmt->fetch();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/profil.php">Profil</a> / Modifier mon profil
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Modifier mon profil</h1>
            <h2>Mettez à jour vos informations personnelles sur NexusDistro.</h2>
            <p><a href="<?= $base_url ?>/pages/profil.php" class="cyan-link">← Retour au profil</a></p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link"><?= htmlspecialchars($profil['username']) ?>@nexusdistro</span>:~$ usermod --edit</p>
                <br>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message) ?></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <p><label>Email :</label></p>
                    <p><input type="email" name="email" value="<?= htmlspecialchars($profil['email']) ?>" class="tab-btn" required></p>
                    <br>
                    <p><label>Nom du fichier Avatar :</label></p>
                    <p><input type="text" name="avatar" value="<?= htmlspecialchars($profil['avatar']) ?>" class="tab-btn"></p>
                    <br>
                    <p><label>Biographie :</label></p>
                    <p><textarea name="biographie" rows="4" class="tab-btn"><?= htmlspecialchars($profil['biographie'] ?? '') ?></textarea></p>
                    <br>
                    <p><label>Nouveau mot de passe (laisser vide pour conserver l'actuel) :</label></p>
                    <p><input type="password" name="new_password" class="tab-btn"></p>
                    <br>
                    <button type="submit" class="tab-btn active">Enregistrer les modifications</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>