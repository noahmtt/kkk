<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom ASC")->fetchAll();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom'] ?? '');
    $version = trim($_POST['version'] ?? '');
    $id_cat = (int)($_POST['id_cat'] ?? 0) ?: null;
    $description = trim($_POST['description'] ?? '');
    $lien = trim($_POST['lien_telechargement'] ?? '');
    $logo = trim($_POST['image_logo'] ?? 'linux.png');

    if ($nom !== '' && $version !== '') {
        $stmt = $pdo->prepare("INSERT INTO distributions (nom, version, id_cat, description, lien_telechargement, image_logo) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nom, $version, $id_cat, $description, $lien, $logo]);
        $message = "La distribution {$nom} a été ajoutée à NexusDistro !";
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/dashboard_admin.php">Admin</a> / Ajouter une distribution
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Ajouter une distribution</h1>
            <h2>Référencez une nouvelle distribution GNU/Linux dans la base <code>nexus.db</code>.</h2>
            <p><a href="<?= $base_url ?>/pages/dashboard_admin.php" class="cyan-link">← Retour au Dashboard</a></p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">root@nexusdistro</span>:~# nexus-pkg --add-distro</p>
                <br>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message) ?></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <p><label>Nom de la distribution * :</label></p>
                    <p><input type="text" name="nom" class="tab-btn" required></p>
                    <br>
                    <p><label>Version * :</label></p>
                    <p><input type="text" name="version" class="tab-btn" required></p>
                    <br>
                    <p><label>Catégorie :</label></p>
                    <p>
                        <select name="id_cat" class="tab-btn">
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id_cat'] ?>"><?= htmlspecialchars($c['nom']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </p>
                    <br>
                    <p><label>Lien de téléchargement (ISO) :</label></p>
                    <p><input type="url" name="lien_telechargement" class="tab-btn"></p>
                    <br>
                    <p><label>Fichier Logo :</label></p>
                    <p><input type="text" name="image_logo" value="linux.png" class="tab-btn"></p>
                    <br>
                    <p><label>Description :</label></p>
                    <p><textarea name="description" rows="4" class="tab-btn" required></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">Ajouter au catalogue</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>