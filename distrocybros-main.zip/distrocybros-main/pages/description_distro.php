<?php
require_once __DIR__ . '/../includes/header.php';

$id_distro = (int)($_GET['id'] ?? 0);

// Ajout de commentaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contenu']) && isset($_SESSION['user'])) {
    $contenu = trim($_POST['contenu']);
    if ($contenu !== '') {
        $ins = $pdo->prepare("INSERT INTO commentaires (id_distro, id_user, contenu) VALUES (?, ?, ?)");
        $ins->execute([$id_distro, $_SESSION['user']['id_user'], $contenu]);
        header("Location: {$base_url}/pages/description_distro.php?id={$id_distro}");
        exit;
    }
}

$stmt = $pdo->prepare("
    SELECT d.*, c.nom AS categorie, c.description AS cat_desc,
           COALESCE(AVG(e.note), 0) AS moyenne, COUNT(e.id_eval) AS nb_notes
    FROM distributions d
    LEFT JOIN categories c ON d.id_cat = c.id_cat
    LEFT JOIN evaluations e ON d.id_distro = e.id_distro
    WHERE d.id_distro = ?
    GROUP BY d.id_distro
");
$stmt->execute([$id_distro]);
$distro = $stmt->fetch();

if (!$distro) {
    echo '<div class="container"><div class="terminal-mockup"><p class="white-text">[!] Distribution introuvable.</p><a href="' . $base_url . '/index.php" class="cyan-link">Retour</a></div></div>';
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

// Vérifier si en favori
$est_favori = false;
if (isset($_SESSION['user'])) {
    $favStmt = $pdo->prepare("SELECT id_favori FROM favoris WHERE id_user = ? AND id_distro = ?");
    $favStmt->execute([$_SESSION['user']['id_user'], $id_distro]);
    $est_favori = (bool)$favStmt->fetch();
}

// Récupérer les commentaires
$commStmt = $pdo->prepare("
    SELECT cm.*, u.username 
    FROM commentaires cm 
    JOIN utilisateurs u ON cm.id_user = u.id_user 
    WHERE cm.id_distro = ? 
    ORDER BY cm.date_pub DESC
");
$commStmt->execute([$id_distro]);
$commentaires = $commStmt->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/recherche.php">Recherche</a> / <?= htmlspecialchars($distro['nom']) ?>
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1><?= htmlspecialchars($distro['nom']) ?></h1>
            <h2>Version : <?= htmlspecialchars($distro['version']) ?> — <?= htmlspecialchars($distro['categorie'] ?? 'Non classé') ?></h2>
            <p><?= nl2br(htmlspecialchars($distro['description'])) ?></p>
            <ul>
                <li>Note moyenne : <strong><?= number_format((float)$distro['moyenne'], 1) ?> / 5</strong> (<?= (int)$distro['nb_notes'] ?> avis)</li>
                <?php if (!empty($distro['image_logo'])): ?>
    <li style="list-style: none; margin-top: 15px;">
        <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($distro['image_logo']) ?>" alt="Logo <?= htmlspecialchars($distro['nom']) ?>" style="width: 80px; height: 80px; object-fit: contain;">
    </li>
<?php endif; ?>
            </ul>
            <br>
            <div class="tabs-container" style="justify-content: flex-start;">
                <?php if (!empty($distro['lien_telechargement'])): ?>
                    <a href="<?= htmlspecialchars($distro['lien_telechargement']) ?>" target="_blank" class="tab-btn active">Télécharger l'ISO →</a>
                <?php endif; ?>

                <?php if (isset($_SESSION['user'])): ?>
                    <a href="<?= $base_url ?>/pages/favori.php?action=toggle&id=<?= (int)$distro['id_distro'] ?>" class="tab-btn">
                        <?= $est_favori ? '★ Retirer des favoris' : '☆ Ajouter aux favoris' ?>
                    </a>
                    <a href="<?= $base_url ?>/pages/evaluer_distro.php?id=<?= (int)$distro['id_distro'] ?>" class="tab-btn">
                        Noter cette distribution
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-info --distro "<?= htmlspecialchars($distro['nom']) ?>"</p>
                <br>
                <p class="white-text">Nom        : <?= htmlspecialchars($distro['nom']) ?></p>
                <p class="white-text">Version    : <?= htmlspecialchars($distro['version']) ?></p>
                <p class="white-text">Catégorie  : <?= htmlspecialchars($distro['categorie'] ?? 'N/A') ?></p>
                <p class="white-text">Évaluation : <?= number_format((float)$distro['moyenne'], 1) ?>/5</p>
                <p class="comment"># <?= htmlspecialchars($distro['cat_desc'] ?? '') ?></p>
            </div>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Commentaires de la communauté (<?= count($commentaires) ?>)</h2>

        <?php if (isset($_SESSION['user'])): ?>
            <div class="code-block">
                <form method="POST" action="">
                    <p class="comment"># Publier un commentaire en tant que <?= htmlspecialchars($_SESSION['user']['username']) ?></p>
                    <br>
                    <p><textarea name="contenu" rows="3" class="tab-btn" style="width: 100%;" placeholder="Votre retour d'expérience sur cette distribution..." required></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">Envoyer le commentaire</button>
                </form>
            </div>
            <br>
        <?php else: ?>
            <p><a href="<?= $base_url ?>/pages/login.php" class="cyan-link">Connectez-vous</a> pour publier un commentaire ou noter cette distribution.</p>
            <br>
        <?php endif; ?>

        <div class="hero">
            <?php foreach ($commentaires as $cm): ?>
                <div class="terminal-mockup">
                    <p class="comment"># Par @<?= htmlspecialchars($cm['username']) ?> le <?= htmlspecialchars($cm['date_pub']) ?></p>
                    <br>
                    <p class="white-text"><?= nl2br(htmlspecialchars($cm['contenu'])) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>