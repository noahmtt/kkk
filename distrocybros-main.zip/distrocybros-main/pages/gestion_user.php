<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

if (isset($_GET['delete'])) {
    $id_del = (int)$_GET['delete'];
    if ($id_del !== (int)$_SESSION['user']['id_user']) {
        $del = $pdo->prepare("DELETE FROM utilisateurs WHERE id_user = ?");
        $del->execute([$id_del]);
    }
    header("Location: {$base_url}/pages/gestion_user.php");
    exit;
}

$users = $pdo->query("SELECT * FROM utilisateurs ORDER BY id_user ASC")->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/dashboard_admin.php">Admin</a> / Gestion des utilisateurs
    </div>

    <section class="options-section" style="border-top: none; padding-top: 0;">
        <h2 class="section-title">Comptes utilisateurs NexusDistro (<?= count($users) ?>)</h2>
        
        <!-- Grille 2 colonnes de largeur et hauteur strictement identiques -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; align-items: stretch;">
            <?php foreach ($users as $u): ?>
                <div class="terminal-mockup" style="display: flex; align-items: center; gap: 24px; text-align: left; height: 100%; min-height: 170px;">
                    
                    <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($u['avatar'] ?: 'default.png') ?>" 
                         alt="Avatar de <?= htmlspecialchars($u['username']) ?>" 
                         style="width: 110px; height: 110px; min-width: 110px; max-width: 110px; object-fit: cover; border-radius: 8px; border: 1.5px solid var(--accent-cyan); flex-shrink: 0;">

                    <div style="display: flex; flex-direction: column; justify-content: center; flex-grow: 1; min-width: 0;">
                        <h3 class="white-text" style="margin-bottom: 4px;">@<?= htmlspecialchars($u['username']) ?> <small>[<?= htmlspecialchars($u['role']) ?>]</small></h3>
                        <p class="comment" style="margin-bottom: 10px;"># ID : <?= (int)$u['id_user'] ?> | Email : <?= htmlspecialchars($u['email']) ?></p>
                        <p style="margin-bottom: 12px;"><?= htmlspecialchars($u['biographie'] ?: 'Aucune biographie.') ?></p>
                        <div>
                            <a href="<?= $base_url ?>/pages/promouvoir.php?id=<?= (int)$u['id_user'] ?>" class="cyan-link">
                                <?= $u['role'] === 'admin' ? 'Rétrograder en User' : 'Promouvoir en Admin' ?>
                            </a>
                            <?php if ((int)$u['id_user'] !== (int)$_SESSION['user']['id_user']): ?>
                                | <a href="<?= $base_url ?>/pages/gestion_user.php?delete=<?= (int)$u['id_user'] ?>" class="cyan-link">Supprimer</a>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>