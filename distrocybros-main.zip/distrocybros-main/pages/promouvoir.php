<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

$id_user = (int)($_GET['id'] ?? 0);

if ($id_user > 0) {
    $stmt = $pdo->prepare("SELECT id_user, username, role FROM utilisateurs WHERE id_user = ?");
    $stmt->execute([$id_user]);
    $u = $stmt->fetch();

    if ($u) {
        $nouveau_role = ($u['role'] === 'admin') ? 'user' : 'admin';
        $upd = $pdo->prepare("UPDATE utilisateurs SET role = ? WHERE id_user = ?");
        $upd->execute([$nouveau_role, $id_user]);
    }
}

header("Location: {$base_url}/pages/gestion_user.php");
exit;