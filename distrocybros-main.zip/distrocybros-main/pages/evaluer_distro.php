<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

$id_distro = (int)($_GET['id'] ?? $_POST['id_distro'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM distributions WHERE id_distro = ?");
$stmt->execute([$id_distro]);
$distro = $stmt->fetch();

if (!$distro) {
    header("Location: {$base_url}/pages/recherche.php");
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note'])) {
    $note = (int)$_POST['note'];
    if ($note >= 1 && $note <= 5) {
        $eval = $pdo->prepare("
            INSERT INTO evaluations (id_distro, id_user, note) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE note = VALUES(note)
        ");
        $eval->execute([$id_distro, $_SESSION['user']['id_user'], $note]);
        $message = "Votre note ({$note}/5) a bien été enregistrée !";
    }
}

// Récupérer la note actuelle de l'utilisateur
$cur = $pdo->prepare("SELECT note FROM evaluations WHERE id_distro = ? AND id_user = ?");
$cur->execute([$id_distro, $_SESSION['user']['id_user']]);
$note_actuelle = $cur->fetchColumn();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/description_distro.php?id=<?= $id_distro ?>"><?= htmlspecialchars($distro['nom']) ?></a> / Évaluer
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Évaluer <?= htmlspecialchars($distro['nom']) ?></h1>
            <h2>Attribuez une note de 1 à 5 à la version <?= htmlspecialchars($distro['version']) ?>.</h2>
            <?php if ($note_actuelle): ?>
                <p>Votre note actuelle : <strong><?= (int)$note_actuelle ?> / 5</strong></p>
            <?php endif; ?>
            <p><a href="<?= $base_url ?>/pages/description_distro.php?id=<?= $id_distro ?>" class="cyan-link">← Retourner sur la fiche de la distribution</a></p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-rate --distro <?= $id_distro ?></p>
                <br>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message) ?></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="hidden" name="id_distro" value="<?= $id_distro ?>">
                    <div class="tabs-container">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <button type="submit" name="note" value="<?= $i ?>" class="tab-btn <?= (int)$note_actuelle === $i ? 'active' : '' ?>">
                                <?= $i ?> ★
                            </button>
                        <?php endfor; ?>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>