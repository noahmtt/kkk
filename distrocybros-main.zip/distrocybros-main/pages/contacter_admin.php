<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

$message_ok = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sujet = trim($_POST['sujet'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($sujet !== '' && $message !== '') {
        $stmt = $pdo->prepare("INSERT INTO messages_admin (id_user, sujet, message) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['user']['id_user'], $sujet, $message]);
        $message_ok = "Votre message a bien été transmis aux administrateurs de NexusDistro.";
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Contacter l'administrateur
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Contacter l'équipe NexusDistro</h1>
            <h2>Suggérez l'ajout d'une nouvelle distribution GNU/Linux ou signalez un problème technique.</h2>
            <p>Votre message sera directement visible dans le tableau de bord d'administration.</p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link"><?= htmlspecialchars($_SESSION['user']['username']) ?>@nexusdistro</span>:~$ mail -s "Support" admin@nexusdistro</p>
                <br>
                <?php if ($message_ok): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message_ok) ?></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <p><label>Sujet :</label></p>
                    <p><input type="text" name="sujet" class="tab-btn" required></p>
                    <br>
                    <p><label>Message :</label></p>
                    <p><textarea name="message" rows="5" class="tab-btn" required></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">Envoyer le message</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>