<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

// Génération du dump SQL téléchargeable
if (isset($_GET['download']) && $_GET['download'] === '1') {
    ob_clean();
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="backup_nexus_' . date('Y-m-d_H-i') . '.sql"');

    echo "-- Sauvegarde NexusDistro (Base : `nexus.db`)\n";
    echo "-- Date : " . date('Y-m-d H:i:s') . "\n\n";
    echo "CREATE DATABASE IF NOT EXISTS `nexus.db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n";
    echo "USE `nexus.db`;\n\n";

    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $create = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch();
        echo "DROP TABLE IF EXISTS `{$table}`;\n";
        echo $create['Create Table'] . ";\n\n";

        $rows = $pdo->query("SELECT * FROM `{$table}`")->fetchAll();
        foreach ($rows as $row) {
            $cols = array_map(fn($c) => "`$c`", array_keys($row));
            $vals = array_map(fn($v) => $v === null ? "NULL" : $pdo->quote($v), array_values($row));
            echo "INSERT INTO `{$table}` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ");\n";
        }
        echo "\n";
    }
    exit;
}

$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / <a href="<?= $base_url ?>/pages/dashboard_admin.php">Admin</a> / Sauvegarde Base de données
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Sauvegarde de <code>nexus.db</code></h1>
            <h2>Exportez l'intégralité des tables et des données de NexusDistro au format SQL.</h2>
            <p>Tables détectées dans <code>nexus.db</code> :</p>
            <ul>
                <?php foreach ($tables as $t): ?>
                    <li><code><?= htmlspecialchars($t) ?></code></li>
                <?php endforeach; ?>
            </ul>
            <br>
            <a href="<?= $base_url ?>/pages/admin_backup.php?download=1" class="tab-btn active">Télécharger le fichier .SQL</a>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">root@nexusdistro</span>:~# mysqldump nexus.db > backup_nexus.sql</p>
                <br>
                <p class="white-text">[+] Base cible : nexus.db</p>
                <p class="white-text">[+] Nombre de tables : <?= count($tables) ?></p>
                <p class="comment"># Cliquez sur "Télécharger le fichier .SQL" pour récupérer votre sauvegarde complète.</p>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>