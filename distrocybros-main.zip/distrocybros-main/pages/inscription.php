<?php
require_once __DIR__ . '/../includes/header.php';

$message = '';
$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $biographie = trim($_POST['biographie'] ?? '');

    if ($username && $email && $password) {
        $check = $pdo->prepare("SELECT id_user FROM utilisateurs WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            $erreur = "Ce nom d'utilisateur ou cet email est déjà utilisé.";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO utilisateurs (username, email, password, role, biographie) VALUES (?, ?, ?, 'user', ?)");
            $stmt->execute([$username, $email, $hash, $biographie]);
            $message = "Compte créé avec succès ! Vous pouvez maintenant vous connecter.";
        }
    } else {
        $erreur = "Veuillez remplir tous les champs obligatoires.";
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Inscription
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Rejoindre NexusDistro</h1>
            <h2>Créez votre profil pour partager vos avis, noter vos systèmes favoris et échanger avec la communauté.</h2>
            <p>Avantages membres :</p>
            <ul>
                <li>Sauvegarde de vos distributions favorites</li>
                <li>Publication de commentaires et d'évaluations</li>
                <li>Contact direct avec l'équipe d'administration</li>
            </ul>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ useradd --create-profile</p>
                <br>
                <?php if ($erreur): ?>
                    <p class="white-text">[!] <?= htmlspecialchars($erreur) ?></p><br>
                <?php endif; ?>
                <?php if ($message): ?>
                    <p class="white-text">[+] <?= htmlspecialchars($message) ?> <a href="<?= $base_url ?>/pages/login.php" class="cyan-link">Connexion →</a></p><br>
                <?php endif; ?>

                <form method="POST" action="">
                    <p><label>Nom d'utilisateur * :</label></p>
                    <p><input type="text" name="username" class="tab-btn" required></p>
                    <br>
                    <p><label>Email * :</label></p>
                    <p><input type="email" name="email" class="tab-btn" required></p>
                    <br>
                    <p><label>Mot de passe * :</label></p>
                    <p><input type="password" name="password" class="tab-btn" required></p>
                    <br>
                    <p><label>Biographie :</label></p>
                    <p><textarea name="biographie" rows="3" class="tab-btn"></textarea></p>
                    <br>
                    <button type="submit" class="tab-btn active">S'inscrire</button>
                </form>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>