<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user'])) {
    header("Location: {$base_url}/pages/login.php");
    exit;
}

$id_user = (int)$_SESSION['user']['id_user'];
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id_user = ?");
$stmt->execute([$id_user]);
$profil = $stmt->fetch();

$nbFav = $pdo->prepare("SELECT COUNT(*) FROM favoris WHERE id_user = ?");
$nbFav->execute([$id_user]);

$nbEval = $pdo->prepare("SELECT COUNT(*) FROM evaluations WHERE id_user = ?");
$nbEval->execute([$id_user]);

$nbComm = $pdo->prepare("SELECT COUNT(*) FROM commentaires WHERE id_user = ?");
$nbComm->execute([$id_user]);
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Mon Profil
    </div>

    <section class="hero">
        <!-- Disposition Flex : grand avatar carré à gauche + informations à droite -->
        <div class="hero-content" style="display: flex; gap: 30px; align-items: flex-start;">
            
            <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($profil['avatar'] ?: 'default.png') ?>" 
                 alt="Avatar de <?= htmlspecialchars($profil['username']) ?>" 
                 style="width: 160px; height: 160px; object-fit: cover; border-radius: 8px; border: 1px solid var(--accent-cyan); flex-shrink: 0;">

            <div>
                <h1>Profil de <?= htmlspecialchars($profil['username']) ?></h1>
                <h2>Rôle : <?= htmlspecialchars(strtoupper($profil['role'])) ?></h2>
                <p><?= nl2br(htmlspecialchars($profil['biographie'] ?: 'Aucune biographie renseignée.')) ?></p>
                <ul>
                    <li>Email : <?= htmlspecialchars($profil['email']) ?></li>
                    <li>Distributions favorites : <?= (int)$nbFav->fetchColumn() ?></li>
                    <li>Notes attribuées : <?= (int)$nbEval->fetchColumn() ?></li>
                    <li>Commentaires postés : <?= (int)$nbComm->fetchColumn() ?></li>
                </ul>
                <br>
                <a href="<?= $base_url ?>/pages/modifier_profil.php" class="tab-btn active" style="display: inline-block; text-decoration: none;">Modifier mon profil</a>
            </div>

        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link"><?= htmlspecialchars($profil['username']) ?>@nexusdistro</span>:~$ whoami --verbose</p>
                <br>
                <p class="white-text">UID        : <?= (int)$profil['id_user'] ?></p>
                <p class="white-text">Username   : <?= htmlspecialchars($profil['username']) ?></p>
                <p class="white-text">Groupe     : <?= htmlspecialchars($profil['role']) ?></p>
                <p class="white-text">Avatar     : <?= htmlspecialchars($profil['avatar']) ?></p>
                <p class="comment"># Bio : <?= htmlspecialchars($profil['biographie'] ?? '') ?></p>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>