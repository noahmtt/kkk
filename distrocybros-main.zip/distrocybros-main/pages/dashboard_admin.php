<?php
require_once __DIR__ . '/../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: {$base_url}/index.php");
    exit;
}

// Suppression éventuelle d'une distribution ou d'un message
if (isset($_GET['del_distro'])) {
    $del = $pdo->prepare("DELETE FROM distributions WHERE id_distro = ?");
    $del->execute([(int)$_GET['del_distro']]);
    header("Location: {$base_url}/pages/dashboard_admin.php");
    exit;
}
if (isset($_GET['del_msg'])) {
    $del = $pdo->prepare("DELETE FROM messages_admin WHERE id_msg = ?");
    $del->execute([(int)$_GET['del_msg']]);
    header("Location: {$base_url}/pages/dashboard_admin.php");
    exit;
}

$nbUsers = $pdo->query("SELECT COUNT(*) FROM utilisateurs")->fetchColumn();
$nbDistros = $pdo->query("SELECT COUNT(*) FROM distributions")->fetchColumn();
$nbMsgs = $pdo->query("SELECT COUNT(*) FROM messages_admin")->fetchColumn();

$messages = $pdo->query("
    SELECT m.*, u.username, u.email 
    FROM messages_admin m 
    JOIN utilisateurs u ON m.id_user = u.id_user 
    ORDER BY m.date_envoi DESC
")->fetchAll();

$distros = $pdo->query("SELECT d.*, c.nom AS categorie FROM distributions d LEFT JOIN categories c ON d.id_cat = c.id_cat ORDER BY d.id_distro DESC")->fetchAll();
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Administration NexusDistro
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Dashboard Administrateur</h1>
            <h2>Supervision de la plateforme NexusDistro et de la base <code>nexus.db</code>.</h2>
            <ul>
                <li>Utilisateurs inscrits : <strong><?= (int)$nbUsers ?></strong></li>
                <li>Distributions référencées : <strong><?= (int)$nbDistros ?></strong></li>
                <li>Messages reçus : <strong><?= (int)$nbMsgs ?></strong></li>
            </ul>
            <br>
            <div class="tabs-container" style="justify-content: flex-start;">
                <a href="<?= $base_url ?>/pages/ajouter_distro.php" class="tab-btn active">+ Ajouter une distribution</a>
                <a href="<?= $base_url ?>/pages/gestion_user.php" class="tab-btn">Gérer les utilisateurs</a>
                <a href="<?= $base_url ?>/pages/admin_backup.php" class="tab-btn">Backup SQL</a>
            </div>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">root@nexusdistro</span>:~# systemctl status nexusdistro</p>
                <br>
                <p class="white-text">● nexusdistro.service - NexusDistro Core</p>
                <p class="white-text">   Active: active (running)</p>
                <p class="white-text">   Database: nexus.db (Connected)</p>
                <p class="comment"># Utilisez les outils ci-dessous pour gérer le contenu.</p>
            </div>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Messages des utilisateurs (<?= count($messages) ?>)</h2>
        
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; align-items: stretch;">
            <?php foreach ($messages as $m): ?>
                <div class="terminal-mockup" style="display: flex; flex-direction: column; justify-content: space-between; text-align: left; height: 100%; min-height: 150px;">
                    <div>
                        <h3 class="white-text"><?= htmlspecialchars($m['sujet']) ?></h3>
                        <p class="comment"># De : <?= htmlspecialchars($m['username']) ?> (<?= htmlspecialchars($m['email']) ?>) — <?= htmlspecialchars($m['date_envoi']) ?></p>
                        <br>
                        <p><?= nl2br(htmlspecialchars($m['message'])) ?></p>
                    </div>
                    <div style="margin-top: 15px;">
                        <a href="<?= $base_url ?>/pages/dashboard_admin.php?del_msg=<?= (int)$m['id_msg'] ?>" class="cyan-link">Supprimer ce message</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="options-section">
        <h2 class="section-title">Gestion des distributions (<?= count($distros) ?>)</h2>
        
        <!-- Grille 2 colonnes de largeur et hauteur strictement identiques -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; align-items: stretch;">
            <?php foreach ($distros as $d): ?>
                <div class="terminal-mockup" style="display: flex; align-items: center; gap: 22px; text-align: left; height: 100%; min-height: 135px;">
                    
                    <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($d['image_logo'] ?: 'linux.png') ?>" 
                         alt="Logo <?= htmlspecialchars($d['nom']) ?>" 
                         style="width: 75px; height: 75px; min-width: 75px; max-width: 75px; object-fit: contain; flex-shrink: 0;">

                    <div style="display: flex; flex-direction: column; justify-content: center; flex-grow: 1; min-width: 0;">
                        <h3 class="white-text" style="margin-bottom: 4px;"><?= htmlspecialchars($d['nom']) ?> <small>(<?= htmlspecialchars($d['version']) ?>)</small></h3>
                        <p class="comment" style="margin-bottom: 12px;"># Catégorie : <?= htmlspecialchars($d['categorie'] ?? 'N/A') ?></p>
                        <div>
                            <a href="<?= $base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="cyan-link">Voir</a> | 
                            <a href="<?= $base_url ?>/pages/dashboard_admin.php?del_distro=<?= (int)$d['id_distro'] ?>" class="cyan-link">Supprimer</a>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>