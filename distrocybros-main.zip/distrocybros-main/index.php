<?php
require_once __DIR__ . '/includes/header.php';

$stmt = $pdo->query("SELECT d.*, c.nom AS categorie FROM distributions d LEFT JOIN categories c ON d.id_cat = c.id_cat ORDER BY d.id_distro DESC LIMIT 4");
$distros = $stmt->fetchAll();
?>

<div class="container">
    <!-- Fil d'Ariane -->
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / NexusDistro
    </div>

    <!-- Section Hero (Présentation + Terminal) -->
    <section class="hero">
        <div class="hero-content">
            <h1>Bienvenue sur NexusDistro</h1>
            <h2>Découvrez, comparez, téléchargez et évaluez les meilleures distributions GNU/Linux du moment.</h2>
            <p>Explorez notre sélection des dernières distributions ajoutées sur NexusDistro :</p>
            <ul>
                <?php foreach ($distros as $d): ?>
                    <li>
                        <strong><?= htmlspecialchars($d['nom']) ?></strong> (<?= htmlspecialchars($d['version']) ?>) — <?= htmlspecialchars($d['categorie'] ?? 'Non classé') ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-search --latest --limit 4</p>
                <br>
                <?php foreach ($distros as $d): ?>
                    <p>
                        [+] <strong><?= htmlspecialchars($d['nom']) ?> <?= htmlspecialchars($d['version']) ?></strong> 
                        [<?= htmlspecialchars($d['categorie'] ?? 'Non classé') ?>]
                        — <a href="<?= $base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="cyan-link">Voir la fiche</a>
                    </p>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Section des dernières distributions ajoutées -->
    <section class="options-section">
        <h2 class="section-title">Dernières distributions ajoutées</h2>

        <!-- Grille de vignettes -->
        <div class="neofetch-grid" style="text-align: left;">
            <?php foreach ($distros as $d): 
                $hostname = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $d['nom']));
            ?>
                <article class="neofetch-card">
                    <!-- Colonne Gauche : Uniquement le gros logo -->
                    <div class="neofetch-left">
                        <div class="neofetch-logo-box">
                            <?php if (!empty($d['image_logo'])): ?>
                                <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($d['image_logo']) ?>" alt="Logo <?= htmlspecialchars($d['nom']) ?>">
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Colonne Droite : Toutes les colonnes de la table distributions -->
                    <div class="neofetch-right">
                        <div class="neofetch-user-host">
                            user<span>@</span><?= htmlspecialchars($hostname) ?>
                        </div>
                        <div class="neofetch-separator">-------------------</div>

                        <ul class="neofetch-specs">
                            <li><span class="neofetch-label">Nom:</span> <?= htmlspecialchars($d['nom']) ?> (<?= htmlspecialchars($d['version']) ?>)</li>
                            <li><span class="neofetch-label">Catégorie:</span> <?= htmlspecialchars($d['categorie'] ?? 'Non classé') ?></li>
                            <li><span class="neofetch-label">Type de l'OS:</span> <?= htmlspecialchars($d['os_type'] ?? 'Linux') ?></li>
                            <li><span class="neofetch-label">Pays:</span> <?= htmlspecialchars($d['pays_origine'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Basé sur:</span> <?= htmlspecialchars($d['base_sur'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Environnement bureau:</span> <?= htmlspecialchars($d['environnement_bureau'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Architecture:</span> <?= htmlspecialchars($d['architecture'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Format paquet:</span> <?= htmlspecialchars($d['format_paquet'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Modèle publication:</span> <?= htmlspecialchars($d['modele_publication'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Taille ISO:</span> <?= htmlspecialchars($d['taille_iso'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Mode d'installation:</span> <?= htmlspecialchars($d['methode_installation'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Support multilingue:</span> <?= htmlspecialchars($d['support_multilingue'] ?? 'Oui') ?></li>
                            <li><span class="neofetch-label">Init software:</span> <?= htmlspecialchars($d['init_software'] ?? 'systemd') ?></li>
                            <li><span class="neofetch-label">Statut:</span> <?= htmlspecialchars($d['statut'] ?? 'Actif') ?></li>
                        </ul>

                        <!-- Palette de couleurs + Actions -->
                        <div class="neofetch-Footer">
                            <div class="neofetch-palette">
                                <span class="pal-1"></span>
                                <span class="pal-2"></span>
                                <span class="pal-3"></span>
                                <span class="pal-4"></span>
                                <span class="pal-5"></span>
                                <span class="pal-6"></span>
                                <span class="pal-7"></span>
                                <span class="pal-8"></span>
                            </div>

                            <div class="neofetch-actions">
                                <a href="<?= $base_url ?>/pages/description_distro.php?id=<?= (int)$d['id_distro'] ?>" class="neofetch-btn">Voir la fiche →</a>
                                <?php if (!empty($d['lien_telechargement'])): ?>
                                    <a href="<?= htmlspecialchars($d['lien_telechargement']) ?>" target="_blank" rel="noopener" class="neofetch-btn">[ ISO ↗ ]</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>