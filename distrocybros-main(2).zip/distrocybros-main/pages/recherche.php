<?php
require_once __DIR__ . '/../includes/header.php';

// Connexion basique procédurale (à changer en fonction de l'utilisateur)
$connexion = mysqli_connect("localhost", "root", "", "nexus.db");

$q = $_GET['q'] ?? '';
$resultats = [];
$erreur_sql = "";

//  Requête VULNÉRABLE
if ($q !== '') {
    $sql = "SELECT * FROM distributions WHERE nom = '$q'";
} else {
    $sql = "SELECT * FROM distributions LIMIT 10"; // Affiche 10 résultats par défaut
}

// 3. Exécution avec récupération des erreurs
if ($connexion) {
    $result = mysqli_query($connexion, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $resultats[] = $row;
        }
    } else {
        $erreur_sql = mysqli_error($connexion);
    }
}
?>

<div class="container">
    <div class="breadcrumb">
        <a href="<?= $base_url ?>/index.php">Accueil</a> / Recherche de distributions
    </div>

    <section class="hero">
        <div class="hero-content">
            <h1>Explorer NexusDistro</h1>
            <h2>Recherchez une distribution par son nom exact.</h2>
            <p><?= count($resultats) ?> distribution(s) trouvée(s).</p>
        </div>

        <div class="hero-visual">
            <div class="terminal-mockup">
                <p><span class="cyan-link">user@nexusdistro</span>:~$ nexus-search --query</p>
                <br>
                <form method="GET" action="">
                    <p><input type="text" name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Ex: Debian, Ubuntu..." class="tab-btn"></p>
                    <br>
                    <button type="submit" class="tab-btn active">Lancer la recherche</button>
                    <a href="<?= $base_url ?>/pages/recherche.php" class="cyan-link">Réinitialiser</a>
                </form>
            </div>
        </div>
    </section>

    <!-- BLOC DE DEBUG POUR TON TP (Aide visuelle pour tes injections) -->
    <div style="background: #1e1e2e; border: 1px solid #ff5555; padding: 15px; margin: 20px 0; border-radius: 8px;">
        <strong style="color: #ff5555;">Requête SQL générée :</strong><br>
        <code style="color: #a6e3a1; font-size: 1.1em;"><?= htmlspecialchars($sql) ?></code>
        <?php if ($erreur_sql): ?>
            <br><br><strong style="color: #ff5555;">Erreur MySQL :</strong> <span style="color: #fff;"><?= htmlspecialchars($erreur_sql) ?></span>
        <?php endif; ?>
    </div>

    <section class="options-section">
        <!-- Grille de résultats en vignettes (Style Neofetch conservé) -->
        <div class="neofetch-grid" style="text-align: left;">
            <?php foreach ($resultats as $d): 
                $hostname = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $d['nom'] ?? 'distro'));
            ?>
                <article class="neofetch-card">
                    <!-- Colonne Gauche : Logo -->
                    <div class="neofetch-left">
                        <div class="neofetch-logo-box">
                            <?php if (!empty($d['image_logo'])): ?>
                                <img src="<?= $base_url ?>/Ressources/images/<?= htmlspecialchars($d['image_logo']) ?>" alt="Logo">
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Colonne Droite : Specs réduites pour l'exemple -->
                    <div class="neofetch-right">
                        <div class="neofetch-user-host">
                            user<span>@</span><?= htmlspecialchars($hostname) ?>
                        </div>
                        <div class="neofetch-separator">-------------------</div>

                        <ul class="neofetch-specs">
                            <li><span class="neofetch-label">Nom:</span> <?= htmlspecialchars($d['nom'] ?? '') ?> (<?= htmlspecialchars($d['version'] ?? '') ?>)</li>
                            <li><span class="neofetch-label">Type de l'OS:</span> <?= htmlspecialchars($d['os_type'] ?? 'Linux') ?></li>
                            <li><span class="neofetch-label">Basé sur:</span> <?= htmlspecialchars($d['base_sur'] ?? 'N/A') ?></li>
                            <li><span class="neofetch-label">Environnement:</span> <?= htmlspecialchars($d['environnement_bureau'] ?? 'N/A') ?></li>
                        </ul>

                        <div class="neofetch-Footer">
                            <div class="neofetch-palette">
                                <span class="pal-1"></span><span class="pal-2"></span><span class="pal-3"></span><span class="pal-4"></span>
                                <span class="pal-5"></span><span class="pal-6"></span><span class="pal-7"></span><span class="pal-8"></span>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</div>

<?php 
if ($connexion) {
    mysqli_close($connexion);
}
require_once __DIR__ . '/../includes/footer.php'; 
?>
